const { Octokit } = require('@octokit/rest');
const rateLimit = require('./github-rate-limit');

function createClient(accessToken) {
  const octokit = new Octokit({ auth: accessToken });
  const tokenKey = rateLimit.keyForToken(accessToken);

  octokit.hook.wrap('request', async (request, options) => {
    return rateLimit.withRetry(tokenKey, async () => {
      try {
        const response = await request(options);
        rateLimit.noteHeaders(tokenKey, response.headers);
        return response;
      } catch (err) {
        if (rateLimit.isRateLimitError(err)) {
          rateLimit.noteHeaders(tokenKey, err.response?.headers);
        }
        throw err;
      }
    });
  });

  return octokit;
}

async function fetchCoreRateLimit(accessToken) {
  if (!accessToken) return null;
  const tokenKey = rateLimit.keyForToken(accessToken);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch('https://api.github.com/rate_limit', {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
      },
      signal: controller.signal,
    });

    const headers = Object.fromEntries(res.headers.entries());
    if (!res.ok) {
      rateLimit.noteHeaders(tokenKey, headers);
      rateLimit.touchQuotaUpdated(tokenKey);
      throw new Error(`GitHub rate_limit API returned ${res.status}`);
    }

    const data = await res.json();
    if (data?.resources?.core) {
      rateLimit.setQuotaFromCore(tokenKey, data.resources.core);
    }
    rateLimit.noteHeaders(tokenKey, headers);
  } catch (err) {
    rateLimit.touchQuotaUpdated(tokenKey);
    throw err;
  } finally {
    clearTimeout(timer);
  }

  return rateLimit.getQuotaStatus(tokenKey);
}

async function getTokenScopes(octokit) {
  const { headers } = await octokit.request('GET /user');
  const raw = headers['x-oauth-scopes'] || headers['X-OAuth-Scopes'] || '';
  return raw.split(',').map((s) => s.trim()).filter(Boolean);
}

async function getUserRepos(octokit) {
  const repos = [];
  let page = 1;
  while (true) {
    const { data } = await octokit.repos.listForAuthenticatedUser({
      per_page: 100,
      page,
      sort: 'updated',
    });
    if (data.length === 0) break;
    repos.push(...data);
    if (data.length < 100) break;
    page++;
  }
  return repos;
}

async function createStorageRepo(octokit, name, org = null) {
  if (org) {
    const { data } = await octokit.repos.createInOrg({
      org,
      name,
      description: 'GitHub Vault storage repository',
      private: false,
      visibility: 'public',
      auto_init: true,
    });
    return data;
  }

  const { data } = await octokit.repos.createForAuthenticatedUser({
    name,
    description: 'GitHub Vault storage repository',
    private: false,
    visibility: 'public',
    auto_init: true,
  });
  return data;
}

async function listUserOrgs(octokit) {
  const orgs = [];
  let page = 1;
  while (true) {
    const { data } = await octokit.orgs.listForAuthenticatedUser({ per_page: 100, page });
    if (!data.length) break;
    orgs.push(...data);
    if (data.length < 100) break;
    page += 1;
  }
  return orgs;
}

async function getOrg(octokit, org) {
  try {
    const { data } = await octokit.orgs.get({ org });
    return data;
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }
}

async function getOrgRole(octokit, org) {
  try {
    const { data } = await octokit.orgs.getMembershipForAuthenticatedUser({ org });
    return data.role;
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }
}

async function getFileSha(octokit, owner, repo, path, branch) {
  try {
    const { data } = await octokit.repos.getContent({ owner, repo, path, ref: branch });
    if (Array.isArray(data)) return null;
    return data.sha;
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }
}

function isContentsConflict(err) {
  const msg = err.response?.data?.message || err.message || '';
  return err.status === 409 || err.status === 422 || /expected [a-f0-9]{40}/i.test(msg);
}

async function uploadChunk(octokit, owner, repo, path, content, branch, existingSha) {
  let sha = existingSha;
  const maxAttempts = 6;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const params = {
        owner,
        repo,
        path,
        message: `vault: store chunk ${path}`,
        content: content.toString('base64'),
        branch,
      };
      if (sha) params.sha = sha;

      const { data } = await octokit.repos.createOrUpdateFileContents(params);
      return data.content.sha;
    } catch (err) {
      if (!isContentsConflict(err) || attempt === maxAttempts - 1) {
        const msg = err.response?.data?.message || err.message || 'GitHub upload failed';
        if (/too large/i.test(msg)) {
          throw new Error(
            `${msg} Use Git upload mode for large files, or keep API chunks under 95 MB.`
          );
        }
        throw err;
      }
      sha = await getFileSha(octokit, owner, repo, path, branch);
      await new Promise((r) => setTimeout(r, 150 * (attempt + 1)));
    }
  }
}

async function downloadChunk(octokit, owner, repo, path, branch) {
  const auth = await octokit.auth();
  const tokenKey = rateLimit.keyForToken(auth?.token);

  const { data } = await octokit.repos.getContent({ owner, repo, path, ref: branch });
  if (Array.isArray(data)) throw new Error('Expected file, got directory');

  if (data.encoding === 'base64' && data.content) {
    return Buffer.from(data.content, 'base64');
  }

  if (!data.download_url) {
    throw new Error(`GitHub returned no content for ${path}`);
  }

  return rateLimit.withRetry(tokenKey, async () => {
    const response = await fetch(data.download_url, {
      headers: auth?.token
        ? { Authorization: `Bearer ${auth.token}`, Accept: 'application/octet-stream' }
        : { Accept: 'application/octet-stream' },
    });
    if (!response.ok) {
      const err = new Error(`Chunk download failed (${response.status}) for ${path}`);
      err.status = response.status;
      err.response = {
        data: { message: await response.text().catch(() => '') },
        headers: {
          'retry-after': response.headers.get('retry-after'),
          'x-ratelimit-reset': response.headers.get('x-ratelimit-reset'),
        },
      };
      throw err;
    }
    return Buffer.from(await response.arrayBuffer());
  });
}

async function deleteChunk(octokit, owner, repo, path, sha, branch) {
  await octokit.repos.deleteFile({
    owner,
    repo,
    path,
    message: `vault: remove chunk ${path}`,
    sha,
    branch,
  });
}

async function getRepoInfo(octokit, owner, repo) {
  const { data } = await octokit.repos.get({ owner, repo });
  return data;
}

async function setRepoPublic(octokit, owner, repo) {
  const { data } = await octokit.repos.update({
    owner,
    repo,
    private: false,
    visibility: 'public',
  });
  return data;
}

async function findFork(octokit, owner, repo, forkOwner) {
  let page = 1;
  while (true) {
    const { data } = await octokit.repos.listForks({ owner, repo, per_page: 100, page });
    const match = data.find((fork) => fork.owner.login === forkOwner);
    if (match) return match;
    if (data.length < 100) break;
    page += 1;
  }
  return null;
}

async function forkRepo(octokit, owner, repo, forkOwner) {
  const existing = await findFork(octokit, owner, repo, forkOwner);
  if (existing) return existing;

  const { data } = await octokit.repos.createFork({
    owner,
    repo,
    default_branch_only: false,
  });

  const deadline = Date.now() + 120000;
  while (Date.now() < deadline) {
    try {
      const [fOwner, fName] = data.full_name.split('/');
      return await getRepoInfo(octokit, fOwner, fName);
    } catch {
      await new Promise((r) => setTimeout(r, 2000));
    }
  }
  return data;
}

async function mergeUpstream(octokit, owner, repo, branch = 'main') {
  const { data } = await octokit.repos.mergeUpstream({ owner, repo, branch });
  return data;
}

module.exports = {
  createClient,
  fetchCoreRateLimit,
  getTokenScopes,
  getUserRepos,
  listUserOrgs,
  getOrg,
  getOrgRole,
  createStorageRepo,
  uploadChunk,
  getFileSha,
  downloadChunk,
  deleteChunk,
  getRepoInfo,
  setRepoPublic,
  findFork,
  forkRepo,
  mergeUpstream,
};
