const express = require('express');
const storage = require('../services/storage');
const streaming = require('../services/streaming');
const hlsStream = require('../services/hls-stream');
const sharePresence = require('../services/share-presence');
const geoip = require('../services/geoip');
const appUrl = require('../services/app-url');
const shareEmbed = require('../services/share-embed');

const router = express.Router();

async function clientInfoFromRequest(req) {
  const ip = geoip.getClientIp(req);
  const userAgent = String(req.headers['user-agent'] || '').slice(0, 512);
  const geo = await geoip.lookupGeo(ip);
  return { ip, userAgent, geo };
}

function setPresenceRoomMeta(req, token, shared) {
  sharePresence.setRoomMeta(token, {
    userId: shared.user_id,
    fileId: shared.id,
    fileName: shared.name,
    isFolder: !!shared.is_folder,
    shareUrl: appUrl.publicUrl(req, `/share/${token}`),
  });
}

function requireShareToken(req, res) {
  const item = storage.getSharedByToken(req.params.token);
  if (!item) {
    res.status(404).json({ error: 'Share not found' });
    return null;
  }
  return item;
}

function resolveShareFile(req, res) {
  const fileId = req.query.file || null;
  const file = storage.resolveSharedFile(req.params.token, fileId);
  if (!file) {
    res.status(404).json({ error: 'Share not found' });
    return null;
  }
  return file;
}

function clientStreamOnly(req, res, file) {
  if (!storage.getShareClientStreamEnabled(file.user_id)) return false;
  res.status(410).json({
    error: 'Server streaming disabled — decrypt in browser',
    client_stream: true,
  });
  return true;
}

router.get('/share/:token/info', async (req, res) => {
  try {
    const shared = storage.getSharedByToken(req.params.token);
    if (!shared) return res.status(404).json({ error: 'Share not found' });

    const clientStream = storage.getShareClientStreamEnabled(shared.user_id);
    const fileId = req.query.file || null;

    if (shared.is_folder && fileId) {
      const file = storage.resolveSharedFile(req.params.token, fileId);
      if (!file) return res.status(404).json({ error: 'Share not found' });
      return res.json({
        id: file.id,
        name: file.name,
        size: file.size,
        mime_type: file.mime_type,
        chunk_count: file.chunk_count,
        has_thumbnail: await storage.shareThumbnailAvailable(file),
        is_folder: false,
        parent_folder: shared.name,
        client_stream: clientStream,
      });
    }

    if (shared.is_folder) {
      const listing = storage.listSharedFolder(req.params.token);
      const fileCount = listing.files.filter((f) => !f.is_folder).length;
      const folderCount = listing.files.filter((f) => f.is_folder).length;
      return res.json({
        name: shared.name,
        is_folder: true,
        path: shared.path,
        file_count: fileCount,
        folder_count: folderCount,
        item_count: listing.files.length,
        client_stream: clientStream,
      });
    }

    res.json({
      id: shared.id,
      name: shared.name,
      size: shared.size,
      mime_type: shared.mime_type,
      chunk_count: shared.chunk_count,
      has_thumbnail: await storage.shareThumbnailAvailable(shared),
      is_folder: false,
      client_stream: clientStream,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/list', (req, res) => {
  try {
    const listing = storage.listSharedFolder(req.params.token, req.query.path || null);
    if (!listing) return res.status(404).json({ error: 'Share not found' });
    res.json(listing);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/manifest', async (req, res) => {
  try {
    const fileId = req.query.file || null;
    const manifest = await storage.getShareManifest(req.params.token, fileId);
    res.json(manifest);
  } catch (err) {
    res.status(err.message === 'Share not found' ? 404 : 400).json({ error: err.message });
  }
});

router.get('/share/:token/chunk/:index', async (req, res) => {
  try {
    const fileId = req.query.file || null;
    const index = parseInt(req.params.index, 10);
    if (!Number.isFinite(index) || index < 0) {
      return res.status(400).json({ error: 'Invalid chunk index' });
    }
    const { buffer, chunk } = await storage.getShareEncryptedChunk(
      req.params.token,
      fileId,
      index
    );
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Length', buffer.length);
    res.setHeader('X-Chunk-Index', String(chunk.chunk_index));
    res.setHeader('X-Plain-Size', String(chunk.plain_size || chunk.size));
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.send(buffer);
  } catch (err) {
    const code = err.message === 'Share not found' ? 404
      : err.message.includes('disabled') ? 403 : 500;
    res.status(code).json({ error: err.message });
  }
});

router.get('/share/:token/status', (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    if (clientStreamOnly(req, res, file)) return;
    res.json(streaming.getStatus(file.user_id, file.id));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/hls/playlist.m3u8', async (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    if (clientStreamOnly(req, res, file)) return;
    const base = `/api/public/share/${req.params.token}/hls`;
    await hlsStream.servePlaylist(req, res, file.user_id, file.id, base);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/hls/segment/:index.ts', async (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    if (clientStreamOnly(req, res, file)) return;
    await hlsStream.serveSegment(req, res, file.user_id, file.id, req.params.index);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/thumbnail', async (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;

    const thumb = await storage.getShareThumbnail(file);
    if (!thumb) return res.status(404).end();

    res.setHeader('Content-Type', 'image/jpeg');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(thumb);
  } catch {
    res.status(404).end();
  }
});

router.get('/share/:token/embed/stream', async (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    if (!shareEmbed.isEmbedCrawler(req)) {
      return res.status(403).json({ error: 'Embed stream is for link preview crawlers only' });
    }
    await streaming.streamPublic(req, res, file);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/stream', async (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    if (clientStreamOnly(req, res, file)) return;
    await streaming.streamPublic(req, res, file);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.post('/share/:token/stream/start', (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    if (storage.getShareClientStreamEnabled(file.user_id)) {
      return res.json({ ok: true, client_stream: true });
    }
    const viewerId = String(req.body?.viewer_id || '').slice(0, 64);
    if (!viewerId) return res.status(400).json({ error: 'viewer_id required' });

    const { registerStreamViewer } = require('../services/chunk-session');
    registerStreamViewer(file.user_id, file.id, viewerId);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/share/:token/stream/stop', (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;
    const viewerId = String(req.body?.viewer_id || '').slice(0, 64);
    if (!viewerId) return res.status(400).json({ error: 'viewer_id required' });

    hlsStream.releaseShareStream(file.user_id, file.id, viewerId);
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/share/:token/presence/join', async (req, res) => {
  try {
    const shared = requireShareToken(req, res);
    if (!shared) return;
    const viewerId = String(req.body?.viewer_id || '').slice(0, 64);
    if (!viewerId) return res.status(400).json({ error: 'viewer_id required' });

    setPresenceRoomMeta(req, req.params.token, shared);
    const clientInfo = await clientInfoFromRequest(req);
    const viewer = sharePresence.join(req.params.token, viewerId, clientInfo);
    res.json({ viewer, viewers: sharePresence.listViewers(req.params.token) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/share/:token/presence/heartbeat', async (req, res) => {
  try {
    const shared = requireShareToken(req, res);
    if (!shared) return;
    const viewerId = String(req.body?.viewer_id || '').slice(0, 64);
    if (!viewerId) return res.status(400).json({ error: 'viewer_id required' });

    const clientInfo = await clientInfoFromRequest(req);
    const viewer = sharePresence.heartbeat(req.params.token, viewerId, clientInfo);
    if (!viewer) return res.status(404).json({ error: 'Not in room' });
    res.json({ viewers: sharePresence.listViewers(req.params.token) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/share/:token/presence/leave', (req, res) => {
  const viewerId = String(req.body?.viewer_id || '').slice(0, 64);
  if (viewerId) sharePresence.leave(req.params.token, viewerId);
  res.json({ success: true });
});

router.get('/share/:token/presence', (req, res) => {
  if (!requireShareToken(req, res)) return;
  res.json({ viewers: sharePresence.listViewers(req.params.token) });
});

router.get('/share/:token/presence/stream', (req, res) => {
  if (!requireShareToken(req, res)) return;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  sharePresence.subscribe(req.params.token, res);

  const ping = setInterval(() => {
    try {
      res.write(': ping\n\n');
    } catch {
      clearInterval(ping);
    }
  }, 25000);

  req.on('close', () => {
    clearInterval(ping);
    sharePresence.unsubscribe(req.params.token, res);
  });
});

const downloadSession = require('../services/download-session');

function startPublicDownloadJob(file, sessionId) {
  const db = require('../db/database');
  const meta = db.prepare('SELECT chunk_count FROM files WHERE id = ?').get(file.id);
  const chunks = db.prepare('SELECT COUNT(*) as n FROM chunks WHERE file_id = ?').get(file.id);
  const total = meta?.chunk_count || chunks?.n || 1;
  downloadSession.update(sessionId, { total });

  storage.downloadFileWithProgress(
    file.user_id,
    file.id,
    (fetched, chunkTotal, stage) => {
      downloadSession.update(sessionId, {
        fetched,
        total: chunkTotal || total,
        stage: stage || 'fetching',
      });
    }
  ).then(({ buffer, file: fileMeta }) => {
    downloadSession.complete(sessionId, buffer, fileMeta);
  }).catch((err) => {
    downloadSession.fail(sessionId, err.message);
  });
}

router.post('/share/:token/download/prepare', (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;

    if (storage.getShareClientStreamEnabled(file.user_id)) {
      return res.status(410).json({
        error: 'Use client-side download',
        client_stream: true,
      });
    }

    const sessionId = downloadSession.create({
      userId: file.user_id,
      fileId: file.id,
      token: req.params.token,
    });
    const session = downloadSession.get(sessionId);
    startPublicDownloadJob(file, sessionId);

    res.json({
      sessionId,
      authToken: session.authToken,
      expiresAt: session.createdAt + downloadSession.TTL_MS,
      total: file.chunk_count || 1,
      fileName: file.name,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/share/:token/download/status/:sessionId', (req, res) => {
  const file = resolveShareFile(req, res);
  if (!file) return;

  const session = downloadSession.get(req.params.sessionId);
  if (!session || session.token !== req.params.token || session.fileId !== file.id) {
    return res.status(404).json({ error: 'Session not found' });
  }
  res.json(downloadSession.toStatus(session));
});

router.get('/share/:token/download', async (req, res) => {
  try {
    const file = resolveShareFile(req, res);
    if (!file) return;

    const sessionId = req.query.session;
    const authToken = req.query.auth;
    if (sessionId) {
      const session = downloadSession.validate(sessionId, authToken);
      if (!session || session.token !== req.params.token || session.fileId !== file.id) {
        return res.status(404).json({ error: 'Download session not found or expired' });
      }
      if (session.error) return res.status(500).json({ error: session.error });
      if (!session.ready || !session.buffer) {
        return res.status(202).json(downloadSession.toStatus(session));
      }

      return downloadSession.sendPreparedFile(res, session, file.mime_type, file.name);
    }

    const { buffer } = await storage.downloadFile(file.user_id, file.id);
    res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.name)}"`);
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
