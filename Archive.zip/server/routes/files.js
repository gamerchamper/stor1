const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { requireAuth } = require('../middleware/auth');
const { ensureSetup } = require('../middleware/setup');
const storage = require('../services/storage');
const metadata = require('../services/metadata');
const streaming = require('../services/streaming');
const hlsStream = require('../services/hls-stream');
const tasks = require('../services/tasks');

const uploadDir = path.join(__dirname, '../../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({ dest: uploadDir, limits: { fileSize: 10 * 1024 * 1024 * 1024 } });
const chunkUpload = multer({ dest: uploadDir, limits: { fileSize: 100 * 1024 * 1024 } });
const router = express.Router();

const viewMode = require('../services/view-mode');
const downloadSession = require('../services/download-session');

router.get('/download/:id', async (req, res) => {
  try {
    const view = viewMode.parseViewParam(req.query.view);
    const sessionId = req.query.session;
    const authToken = req.query.auth;

    if (sessionId && authToken) {
      const session = downloadSession.validate(sessionId, authToken);
      if (!session || session.fileId !== req.params.id) {
        return res.status(404).json({ error: 'Download session not found or expired' });
      }
      if (session.error) return res.status(500).json({ error: session.error });
      if (!session.ready || !session.buffer) {
        return res.status(202).json(downloadSession.toStatus(session));
      }

      const { file } = session;
      return downloadSession.sendPreparedFile(res, session, file?.mime_type, file?.name);
    }

    if (!req.isAuthenticated || !req.isAuthenticated()) {
      return res.status(401).json({ error: 'Not authenticated' });
    }

    const { buffer, file } = await storage.downloadFile(req.user.id, req.params.id, view);
    res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.name)}"`);
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.use(requireAuth, ensureSetup);

router.get('/list', (req, res) => {
  try {
    const parentPath = req.query.path || '/';
    const view = viewMode.parseViewParam(req.query.view);
    const files = storage.listFiles(req.user.id, parentPath, view);
    res.json({ files, path: parentPath, view: req.query.view || 'primary' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/plan', (req, res) => {
  try {
    const { size, chunkSize } = req.body;
    if (!size) return res.status(400).json({ error: 'size required' });
    res.json(storage.planUpload(
      parseInt(size, 10),
      parseInt(chunkSize, 10) || storage.CHUNK_SIZE,
      req.user.id
    ));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file provided' });

  const jobId = uuidv4();
  const parentPath = req.body.path || '/';
  let chunkSize;
  try {
    chunkSize = storage.normalizeChunkSize(parseInt(req.body.chunkSize, 10) || storage.CHUNK_SIZE);
  } catch (err) {
    fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: err.message });
  }
  const buffer = fs.readFileSync(req.file.path);
  fs.unlinkSync(req.file.path);

  tasks.create(req.user.id, {
    id: jobId,
    type: 'upload',
    title: req.file.originalname,
    payload: { fileName: req.file.originalname },
  });

  storage.uploadFile(
    req.user.id,
    req.file.originalname,
    parentPath,
    buffer,
    req.file.mimetype,
    {
      chunkSize,
      onProgress: (p) => tasks.update(jobId, req.user.id, { ...p, status: 'processing' }),
    }
  ).then((result) => {
    tasks.update(jobId, req.user.id, {
      status: 'done', percent: 100, file: result, phase: 'done',
    });
  }).catch((err) => {
    tasks.update(jobId, req.user.id, { status: 'error', error: err.message });
  });

  const plan = storage.planUpload(buffer.length, chunkSize, req.user.id);
  res.json({ jobId, fileName: req.file.originalname, estimatedChunks: plan.totalChunks });
});

router.get('/upload-progress/:jobId', (req, res) => {
  const job = tasks.get(req.params.jobId, req.user.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});

router.post('/upload/init', async (req, res) => {
  try {
    const {
      fileName, path, parentPath: parentPathField, size, mimeType, chunkSize, fileId, taskId,
    } = req.body;
    const parentPath = parentPathField || path || '/';
    if (!fileName || !size) return res.status(400).json({ error: 'fileName and size required' });

    const jobId = taskId || uuidv4();
    const existingTask = taskId ? tasks.get(taskId, req.user.id) : null;

    if (existingTask) {
      tasks.update(jobId, req.user.id, {
        status: 'processing',
        phase: 'starting',
        error: null,
        title: fileName,
      });
    } else {
      tasks.create(req.user.id, {
        id: jobId,
        type: 'upload',
        title: fileName,
        payload: { fileName, resumable: true },
      });
    }

    const session = await storage.initUploadSession(req.user.id, {
      fileName,
      parentPath: parentPath || '/',
      size: parseInt(size, 10),
      mimeType,
      chunkSize: parseInt(chunkSize, 10) || storage.CHUNK_SIZE,
      fileId,
    });

    const uploadMode = req.body.uploadMode === 'git' ? 'git' : 'api';
    tasks.update(jobId, req.user.id, {
      status: 'processing',
      phase: session.nextChunk >= session.totalChunks ? 'metadata' : 'upload',
      chunksTotal: session.totalChunks,
      chunksDone: session.chunksDone,
      percent: session.percent,
      fileId: session.fileId,
      parentPath: parentPath || '/',
      chunkSize: session.chunkSize,
      fileSize: parseInt(size, 10),
      mimeType: mimeType || 'application/octet-stream',
      resumable: true,
      nextChunk: session.nextChunk,
      uploadMode,
    });
    if (uploadMode === 'git') {
      tasks.appendLog(
        jobId,
        req.user.id,
        `Git upload started — ${session.totalChunks} chunks will stage under data/cache/git-workspaces (push happens at end)`
      );
    }

    res.json({ ...session, jobId, uploadMode });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/upload/chunk', chunkUpload.single('chunk'), async (req, res) => {
  const taskId = req.body.taskId;
  const fileId = req.body.fileId;
  try {
    if (!req.file) return res.status(400).json({ error: 'No chunk provided' });
    if (!fileId) return res.status(400).json({ error: 'fileId required' });

    const buffer = fs.readFileSync(req.file.path);
    fs.unlinkSync(req.file.path);

    if (taskId) {
      const existing = tasks.get(taskId, req.user.id);
      if (existing?.status === 'paused') {
        return res.status(409).json({ error: 'Upload is paused — click Resume to continue' });
      }
    }

    const uploadMode = req.body.uploadMode === 'git' ? 'git' : 'api';
    const chunkIndex = parseInt(req.body.chunkIndex, 10);

    if (taskId) {
      tasks.appendLog(taskId, req.user.id, `Uploading chunk ${chunkIndex} to primary...`, { chunkIndex });
      tasks.update(taskId, req.user.id, {
        status: 'processing',
        phase: 'upload',
        pauseReason: null,
        error: null,
        resumable: true,
      });
    }

    const result = await storage.uploadPlainChunk(
      req.user.id,
      fileId,
      chunkIndex,
      buffer,
      uploadMode,
      taskId ? { taskId, userId: req.user.id } : null
    );

    if (taskId) {
      const patch = {
        status: 'processing',
        phase: 'upload',
        chunksDone: result.chunksDone,
        chunksTotal: result.totalChunks,
        percent: result.percent,
        currentRepo: result.currentRepo || null,
        fileId,
        resumable: true,
        nextChunk: result.nextChunk,
        uploadMode,
      };
      if (uploadMode === 'git' && !result.skipped) {
        const existing = tasks.get(taskId, req.user.id);
        const repos = new Set(existing?.gitRepos || []);
        if (result.currentRepo) repos.add(result.currentRepo);
        patch.gitRepos = [...repos];
        patch.gitBytesStaged = (existing?.gitBytesStaged || 0) + buffer.length;
      }
      if (!result.skipped) {
        tasks.appendLog(
          taskId,
          req.user.id,
          `Stored chunk ${chunkIndex} on primary${uploadMode === 'git' ? '' : ' (backup sync will mirror later)'}`,
          { chunkIndex, repo: result.currentRepo }
        );
      }
      tasks.update(taskId, req.user.id, patch);
    }

    res.json(result);
  } catch (err) {
    if (taskId) {
      tasks.update(taskId, req.user.id, { status: 'error', error: err.message, resumable: true });
      tasks.appendLog(taskId, req.user.id, `Chunk ${chunkIndex} failed: ${err.message}`);
    }
    if (fileId) storage.markUploadFailed(req.user.id, fileId);
    if (req.file?.path && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ error: err.message });
  }
});

router.post('/upload/complete', chunkUpload.single('preview'), async (req, res) => {
  const { fileId, taskId } = req.body;
  try {
    if (!fileId) return res.status(400).json({ error: 'fileId required' });

    let preview = null;
    if (req.file) {
      preview = fs.readFileSync(req.file.path);
      fs.unlinkSync(req.file.path);
    }

    const uploadMode = req.body.uploadMode === 'git' ? 'git' : 'api';
    const result = await storage.finalizeUpload(
      req.user.id,
      fileId,
      preview,
      (p) => {
        if (!taskId) return;
        tasks.update(taskId, req.user.id, { ...p, status: 'processing', fileId, resumable: true });
        if (p.lastLog) tasks.appendLog(taskId, req.user.id, p.lastLog);
      },
      uploadMode,
      taskId ? { taskId, userId: req.user.id } : null
    );

    if (taskId) {
      tasks.update(taskId, req.user.id, {
        status: 'done',
        percent: 100,
        phase: 'done',
        file: result,
        resumable: false,
      });
    }

    res.json(result);
  } catch (err) {
    if (taskId) {
      tasks.update(taskId, req.user.id, { status: 'error', error: err.message, resumable: true });
    }
    if (fileId) storage.markUploadFailed(req.user.id, fileId);
    if (req.file?.path && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ error: err.message });
  }
});

router.get('/upload/session/:fileId', (req, res) => {
  try {
    const session = storage.getUploadSession(req.user.id, req.params.fileId);
    if (!session) return res.status(404).json({ error: 'Upload session not found' });
    res.json(session);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/upload/cancel', async (req, res) => {
  try {
    const { fileId, taskId } = req.body;
    if (fileId) {
      await storage.cancelUploadSession(req.user.id, fileId);
    }
    if (taskId) {
      await tasks.cancelTask(taskId, req.user.id);
    } else if (!fileId) {
      return res.status(400).json({ error: 'taskId or fileId required' });
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/delete-batch', async (req, res) => {
  try {
    const ids = Array.isArray(req.body.ids) ? req.body.ids.filter(Boolean) : [];
    if (!ids.length) return res.status(400).json({ error: 'No items selected' });

    const db = require('../db/database');
    const names = ids.map((id) => {
      const file = db.prepare('SELECT name FROM files WHERE id = ? AND user_id = ?').get(id, req.user.id);
      return file?.name || 'item';
    });

    const taskId = require('uuid').v4();
    const title = ids.length === 1
      ? `Deleting ${names[0]}`
      : `Deleting ${ids.length} items`;

    tasks.create(req.user.id, {
      id: taskId,
      type: 'delete',
      title,
      payload: { ids, names, done: 0, total: ids.length },
    });

    (async () => {
      try {
        for (let i = 0; i < ids.length; i++) {
          tasks.update(taskId, req.user.id, {
            status: 'processing',
            phase: 'delete',
            percent: Math.round((i / ids.length) * 100),
            title: ids.length === 1
              ? `Deleting ${names[i]}`
              : `Deleting ${names[i]} (${i + 1}/${ids.length})`,
            done: i,
            total: ids.length,
            currentName: names[i],
          });
          await storage.deleteFile(req.user.id, ids[i]);
        }
        tasks.update(taskId, req.user.id, {
          status: 'done',
          phase: 'done',
          percent: 100,
          done: ids.length,
          total: ids.length,
        });
      } catch (err) {
        tasks.update(taskId, req.user.id, { status: 'error', error: err.message });
      }
    })();

    res.json({ taskId, count: ids.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/details/:id', (req, res) => {
  try {
    res.json(storage.getFileDetails(req.user.id, req.params.id, req));
  } catch (err) {
    res.status(404).json({ error: err.message });
  }
});

router.post('/share/:id', (req, res) => {
  try {
    res.json(storage.createShareToken(req.user.id, req.params.id, req));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/share/settings', (req, res) => {
  try {
    res.json({
      client_stream: storage.getShareClientStreamEnabled(req.user.id),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/share/settings', (req, res) => {
  try {
    const enabled = !!req.body?.client_stream;
    res.json(storage.setShareClientStreamEnabled(req.user.id, enabled));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/share/:id', (req, res) => {
  try {
    storage.revokeShareToken(req.user.id, req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/refresh-thumbnail/:id', async (req, res) => {
  try {
    const result = await storage.refreshThumbnail(req.user.id, req.params.id);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/thumbnail/:id/refresh', async (req, res) => {
  try {
    const result = await storage.refreshThumbnail(req.user.id, req.params.id);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/thumbnail/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    const fileId = req.params.id;
    const thumbCache = require('../services/thumb-cache');

    let thumb = thumbCache.get(userId, fileId);
    if (!thumb) {
      const file = require('../db/database').prepare(
        'SELECT * FROM files WHERE id = ? AND user_id = ?'
      ).get(fileId, userId);
      if (!file) return res.status(404).end();
      if (file.has_thumbnail) {
        thumb = await metadata.getThumbnail(userId, fileId);
      } else {
        thumb = await storage.getShareThumbnail(file);
      }
    }
    if (!thumb) return res.status(404).end();

    res.setHeader('Content-Type', 'image/jpeg');
    res.setHeader('Cache-Control', 'private, max-age=86400');
    res.send(thumb);
  } catch {
    res.status(404).end();
  }
});

router.get('/view/:id', async (req, res) => {
  try {
    const view = viewMode.parseViewParam(req.query.view);
    await streaming.streamFile(req, res, req.user.id, req.params.id, view);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.get('/stream/:id', async (req, res) => {
  try {
    const view = viewMode.parseViewParam(req.query.view);
    await streaming.streamFile(req, res, req.user.id, req.params.id, view);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.get('/status/:id', (req, res) => {
  try {
    res.json(streaming.getStatus(req.user.id, req.params.id));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/hls/:id/playlist.m3u8', async (req, res) => {
  try {
    const view = viewMode.parseViewParam(req.query.view);
    const base = `/api/files/hls/${req.params.id}`;
    await hlsStream.servePlaylist(req, res, req.user.id, req.params.id, base, view);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

router.get('/hls/:id/segment/:index.ts', async (req, res) => {
  try {
    const view = viewMode.parseViewParam(req.query.view);
    await hlsStream.serveSegment(req, res, req.user.id, req.params.id, req.params.index, view);
  } catch (err) {
    if (!res.headersSent) res.status(500).json({ error: err.message });
  }
});

function startDownloadJob(userId, fileId, sessionId, view) {
  const db = require('../db/database');
  const meta = db.prepare(
    'SELECT name, chunk_count FROM files WHERE id = ? AND user_id = ? AND is_folder = 0'
  ).get(fileId, userId);
  if (!meta) {
    downloadSession.fail(sessionId, 'File not found');
    return;
  }

  const chunks = db.prepare('SELECT COUNT(*) as n FROM chunks WHERE file_id = ?').get(fileId);
  const total = meta.chunk_count || chunks?.n || 1;
  downloadSession.update(sessionId, { total });

  storage.downloadFileWithProgress(
    userId,
    fileId,
    (fetched, chunkTotal, stage) => {
      downloadSession.update(sessionId, {
        fetched,
        total: chunkTotal || total,
        stage: stage || 'fetching',
      });
    },
    view
  ).then(({ buffer, file }) => {
    downloadSession.complete(sessionId, buffer, file);
  }).catch((err) => {
    downloadSession.fail(sessionId, err.message);
  });
}

router.post('/download/:id/prepare', (req, res) => {
  try {
    const view = viewMode.parseViewParam(req.query.view);
    const fileId = req.params.id;
    const db = require('../db/database');
    const file = db.prepare(
      'SELECT name, chunk_count FROM files WHERE id = ? AND user_id = ? AND is_folder = 0'
    ).get(fileId, req.user.id);
    if (!file) return res.status(404).json({ error: 'File not found' });

    const sessionId = downloadSession.create({
      userId: req.user.id,
      fileId,
      view,
    });
    const session = downloadSession.get(sessionId);
    startDownloadJob(req.user.id, fileId, sessionId, view);

    res.json({
      sessionId,
      authToken: session.authToken,
      expiresAt: session.createdAt + downloadSession.TTL_MS,
      total: file.chunk_count || 1,
      fileName: file.name,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/download/status/:sessionId', (req, res) => {
  const session = downloadSession.get(req.params.sessionId);
  if (!session || session.userId !== req.user.id) {
    return res.status(404).json({ error: 'Session not found' });
  }
  res.json(downloadSession.toStatus(session));
});

router.delete('/:id', async (req, res) => {
  try {
    const db = require('../db/database');
    const file = db.prepare('SELECT name FROM files WHERE id = ? AND user_id = ?').get(req.params.id, req.user.id);
    if (!file) return res.status(404).json({ error: 'File not found' });

    const taskId = require('uuid').v4();
    tasks.create(req.user.id, {
      id: taskId,
      type: 'delete',
      title: `Deleting ${file.name}`,
      payload: { ids: [req.params.id], names: [file.name], done: 0, total: 1 },
    });

    storage.deleteFile(req.user.id, req.params.id)
      .then(() => {
        tasks.update(taskId, req.user.id, {
          status: 'done', phase: 'done', percent: 100, done: 1, total: 1,
        });
      })
      .catch((err) => {
        tasks.update(taskId, req.user.id, { status: 'error', error: err.message });
      });

    res.json({ success: true, taskId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/folder', async (req, res) => {
  try {
    const { name, path: parentPath } = req.body;
    if (!name) return res.status(400).json({ error: 'Folder name required' });
    const folder = await storage.createFolder(req.user.id, name, parentPath || '/');
    res.json({ success: true, folder });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/move', async (req, res) => {
  try {
    const ids = Array.isArray(req.body.ids) ? req.body.ids.filter(Boolean) : [];
    const destination = req.body.destination ?? req.body.path ?? '/';
    if (!ids.length) return res.status(400).json({ error: 'No items selected' });
    const result = await storage.moveItems(req.user.id, ids, destination);
    res.json({ success: true, ...result });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/stats', async (req, res) => {
  try {
    res.json(await storage.getStorageStats(req.user.id));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
