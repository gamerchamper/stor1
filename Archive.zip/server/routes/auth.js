const express = require('express');
const passport = require('passport');
const { requireAuth } = require('../middleware/auth');
const accounts = require('../services/accounts');
const router = express.Router();
const appUrl = require('../services/app-url');

const GITHUB_SCOPES = ['repo', 'user', 'read:org'];

function linkErrorPage(message) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Link failed</title>
<style>body{font-family:system-ui,sans-serif;max-width:480px;margin:80px auto;padding:0 20px;color:#333}
h1{font-size:20px}p{line-height:1.5;color:#555}a{color:#0969da}</style></head><body>
<h1>Could not start account link</h1><p>${message}</p>
<p>Go back to GitHub Vault on your main browser, open <strong>Storage Repositories</strong>, and copy a fresh link.</p>
</body></html>`;
}

router.get('/github', (req, res, next) => {
  passport.authenticate('github', { scope: GITHUB_SCOPES })(req, res, next);
});

router.get('/github/link', (req, res, next) => {
  const startOAuth = () => {
    passport.authenticate('github', { scope: GITHUB_SCOPES })(req, res, next);
  };

  if (req.query.token) {
    try {
      const row = accounts.peekLinkToken(req.query.token);
      req.session.linkingForUserId = row.user_id;
      req.session.linkingRole = row.role;
      req.session.linkingToken = req.query.token;
      return startOAuth();
    } catch (err) {
      return res.status(400).send(linkErrorPage(err.message));
    }
  }

  if (!req.isAuthenticated || !req.isAuthenticated()) {
    return res.status(401).json({
      error: 'Not authenticated — open Storage Repositories and copy a one-time link instead',
    });
  }

  const role = req.query.role === 'backup' ? 'backup' : 'storage';
  req.session.linkingForUserId = req.user.id;
  req.session.linkingRole = role;
  startOAuth();
});

router.get('/github/reconnect', (req, res, next) => {
  passport.authenticate('github', {
    scope: GITHUB_SCOPES,
    authorizationParams: { prompt: 'consent' },
  })(req, res, next);
});

router.get('/github/callback', (req, res, next) => {
  const wasLinking = !!(req.session?.linkingForUserId || req.session?.linkingToken);

  passport.authenticate('github', (err, user) => {
    if (err) {
      const reason = encodeURIComponent(err.message || 'Authentication failed');
      delete req.session.linkingForUserId;
      delete req.session.linkingRole;
      delete req.session.linkingToken;
      if (wasLinking) return res.redirect(`/?error=link_failed&reason=${reason}`);
      return res.redirect(`/?error=auth_failed&reason=${reason}`);
    }
    if (!user) {
      delete req.session.linkingToken;
      if (wasLinking) return res.redirect('/?error=link_failed');
      return res.redirect('/?error=auth_failed');
    }

    req.logIn(user, (loginErr) => {
      if (loginErr) return res.redirect('/?error=auth_failed');
      if (req.session.linkedSuccess) {
        delete req.session.linkedSuccess;
        return res.redirect('/?linked=1');
      }
      console.log(`User logged in: ${req.user.username} (id=${req.user.id})`);
      res.redirect('/');
    });
  })(req, res, next);
});

router.get('/me', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  if (!req.isAuthenticated || !req.isAuthenticated()) {
    return res.json({ authenticated: false, app_url: appUrl.getAppUrl(req) });
  }
  res.json({
    authenticated: true,
    app_url: appUrl.getAppUrl(req),
    user: {
      id: req.user.id,
      username: req.user.username,
      avatar: req.user.avatar_url,
    },
  });
});

router.post('/logout', (req, res) => {
  req.logout((err) => {
    if (err) return res.status(500).json({ error: 'Logout failed' });
    req.session = null;
    res.json({ success: true });
  });
});

module.exports = router;
