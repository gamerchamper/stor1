const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'vault.db'));
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    github_id TEXT UNIQUE NOT NULL,
    username TEXT NOT NULL,
    avatar_url TEXT,
    access_token TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS storage_repos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    owner TEXT NOT NULL,
    name TEXT NOT NULL,
    full_name TEXT NOT NULL,
    default_branch TEXT DEFAULT 'main',
    is_active INTEGER DEFAULT 1,
    chunk_count INTEGER DEFAULT 0,
    total_bytes INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(user_id, full_name)
  );

  CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    path TEXT NOT NULL,
    size INTEGER NOT NULL,
    mime_type TEXT,
    is_folder INTEGER DEFAULT 0,
    parent_path TEXT DEFAULT '/',
    chunk_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_id TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    repo_id INTEGER NOT NULL,
    repo_path TEXT NOT NULL,
    sha TEXT,
    size INTEGER NOT NULL,
    FOREIGN KEY (file_id) REFERENCES files(id),
    FOREIGN KEY (repo_id) REFERENCES storage_repos(id),
    UNIQUE(file_id, chunk_index)
  );

  CREATE INDEX IF NOT EXISTS idx_files_user_path ON files(user_id, parent_path);
  CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file_id);

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'processing',
    phase TEXT DEFAULT 'starting',
    percent INTEGER DEFAULT 0,
    error TEXT,
    payload TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE INDEX IF NOT EXISTS idx_tasks_user_status ON tasks(user_id, status);

  CREATE TABLE IF NOT EXISTS linked_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    github_id TEXT NOT NULL,
    username TEXT NOT NULL,
    avatar_url TEXT,
    access_token TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'storage',
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE(user_id, github_id)
  );

  CREATE TABLE IF NOT EXISTS link_tokens (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS chunk_backups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chunk_id INTEGER NOT NULL,
    repo_id INTEGER NOT NULL,
    sha TEXT,
    FOREIGN KEY (chunk_id) REFERENCES chunks(id),
    FOREIGN KEY (repo_id) REFERENCES storage_repos(id),
    UNIQUE(chunk_id, repo_id)
  );
`);

const migrations = [
  'ALTER TABLE users ADD COLUMN master_key TEXT',
  'ALTER TABLE storage_repos ADD COLUMN is_metadata INTEGER DEFAULT 0',
  'ALTER TABLE files ADD COLUMN has_thumbnail INTEGER DEFAULT 0',
  'ALTER TABLE files ADD COLUMN encryption_meta TEXT',
  'ALTER TABLE files ADD COLUMN share_token TEXT',
  'ALTER TABLE files ADD COLUMN encryption_mode TEXT DEFAULT "chunk"',
  'ALTER TABLE chunks ADD COLUMN chunk_iv TEXT',
  'ALTER TABLE chunks ADD COLUMN chunk_tag TEXT',
  'ALTER TABLE chunks ADD COLUMN plain_size INTEGER',
  'ALTER TABLE users ADD COLUMN vault_org TEXT',
  'ALTER TABLE files ADD COLUMN upload_status TEXT DEFAULT "ready"',
  'ALTER TABLE storage_repos ADD COLUMN linked_account_id INTEGER',
  'ALTER TABLE storage_repos ADD COLUMN repo_role TEXT DEFAULT "primary"',
  'ALTER TABLE storage_repos ADD COLUMN mirrors_repo_id INTEGER',
  'ALTER TABLE files ADD COLUMN share_key_meta TEXT',
  'ALTER TABLE users ADD COLUMN share_client_stream INTEGER DEFAULT 1',
  'ALTER TABLE storage_repos ADD COLUMN is_public INTEGER DEFAULT 0',
];

for (const sql of migrations) {
  try { db.exec(sql); } catch { /* column exists */ }
}

module.exports = db;
