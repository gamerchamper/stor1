const API = {
  async get(url) {
    const res = await fetch(url, { credentials: 'same-origin' });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || 'Request failed');
    }
    return res.json();
  },

  async post(url, body = {}) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || res.statusText || 'Request failed');
    }
    return res.json();
  },

  async delete(url) {
    const res = await fetch(url, { method: 'DELETE', credentials: 'same-origin' });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || 'Request failed');
    }
    return res.json();
  },

  async upload(file, path, chunkSize, onProgress, uploadMode = 'api') {
    return UploadManager.start(file, path, chunkSize, onProgress, uploadMode);
  },

  async uploadChunk(fileId, chunkIndex, blob, taskId, uploadMode = 'api', signal) {
    const form = new FormData();
    form.append('chunk', blob, `chunk-${chunkIndex}`);
    form.append('fileId', fileId);
    form.append('chunkIndex', String(chunkIndex));
    form.append('taskId', taskId);
    form.append('uploadMode', uploadMode);

    const res = await fetch('/api/files/upload/chunk', {
      method: 'POST',
      body: form,
      credentials: 'same-origin',
      signal,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Chunk upload failed' }));
      throw new Error(err.error || 'Chunk upload failed');
    }
    return res.json();
  },

  async uploadComplete(fileId, taskId, preview, uploadMode = 'api') {
    const form = new FormData();
    form.append('fileId', fileId);
    form.append('taskId', taskId);
    form.append('uploadMode', uploadMode);
    if (preview) form.append('preview', preview, 'preview.bin');

    const res = await fetch('/api/files/upload/complete', {
      method: 'POST',
      body: form,
      credentials: 'same-origin',
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: 'Upload finalize failed' }));
      throw new Error(err.error || 'Upload finalize failed');
    }
    return res.json();
  },

  auth: {
    me: () => API.get('/auth/me'),
    logout: () => API.post('/auth/logout'),
  },

  viewQuery(view) {
    if (!view || view === 'primary') return '';
    return `?view=${encodeURIComponent(view)}`;
  },

  files: {
    list: (path, view) => {
      const params = new URLSearchParams({ path });
      if (view && view !== 'primary') params.set('view', view);
      return API.get(`/api/files/list?${params}`);
    },
    upload: (file, path, chunkSize, onProgress, uploadMode) =>
      API.upload(file, path, chunkSize, onProgress, uploadMode),
    uploadInit: (data) => API.post('/api/files/upload/init', data),
    uploadChunk: (fileId, chunkIndex, blob, taskId, uploadMode, signal) =>
      API.uploadChunk(fileId, chunkIndex, blob, taskId, uploadMode, signal),
    uploadComplete: (fileId, taskId, preview, uploadMode) =>
      API.uploadComplete(fileId, taskId, preview, uploadMode),
    uploadCancel: (fileId, taskId) => API.post('/api/files/upload/cancel', { fileId, taskId }),
    uploadSession: (fileId) => API.get(`/api/files/upload/session/${fileId}`),
    refreshThumbnail: async (id) => {
      try {
        return await API.post(`/api/files/refresh-thumbnail/${id}`);
      } catch (err) {
        if (err.message === 'Not Found') {
          return API.post(`/api/files/thumbnail/${id}/refresh`);
        }
        throw err;
      }
    },
    plan: (size, chunkSize) => API.post('/api/files/plan', { size, chunkSize }),
    details: (id) => API.get(`/api/files/details/${id}`),
    share: (id) => API.post(`/api/files/share/${id}`),
    unshare: (id) => API.delete(`/api/files/share/${id}`),
    shareSettings: () => API.get('/api/files/share/settings'),
    setShareSettings: (clientStream) => API.patch('/api/files/share/settings', { client_stream: clientStream }),
    download: (id, view) => `/api/files/download/${id}${API.viewQuery(view)}`,
    downloadPrepare: (id, view) => {
      const qs = API.viewQuery(view);
      return API.post(`/api/files/download/${id}/prepare${qs}`);
    },
    view: (id, view) => `/api/files/view/${id}${API.viewQuery(view)}`,
    stream: (id, view) => `/api/files/stream/${id}${API.viewQuery(view)}`,
    hlsPlaylist: (id, view) => `/api/files/hls/${id}/playlist.m3u8${API.viewQuery(view)}`,
    status: (id) => API.get(`/api/files/status/${id}`),
    delete: (id) => API.delete(`/api/files/${id}`),
    deleteBatch: (ids) => API.post('/api/files/delete-batch', { ids }),
    createFolder: (name, path) => API.post('/api/files/folder', { name, path }),
    move: (ids, destination) => API.post('/api/files/move', { ids, destination }),
    stats: () => API.get('/api/files/stats'),
  },

  accounts: {
    list: () => API.get('/api/accounts'),
    rateLimits: () => API.get('/api/accounts/rate-limits'),
    createLinkToken: (role) => API.post('/api/accounts/link-token', { role }),
    views: () => API.get('/api/accounts/views'),
    backupStatus: () => API.get('/api/accounts/backup-status'),
    startBackupSync: (accountId, { force = false } = {}) => API.post('/api/accounts/backup-sync', {
      account_id: accountId,
      force,
    }),
    redoBackup: (id) => API.post(`/api/accounts/${id}/redo-backup`),
    update: (id, data) => API.patch(`/api/accounts/${id}`, data),
    unlink: (id) => API.delete(`/api/accounts/${id}`),
    availableRepos: (id) => API.get(`/api/accounts/${id}/repos/available`),
  },

  async patch(url, body = {}) {
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: res.statusText }));
      throw new Error(err.error || res.statusText || 'Request failed');
    }
    return res.json();
  },

  viewers: {
    live: () => API.get('/api/viewers/live'),
  },

  repos: {
    available: () => API.get('/api/repos/available'),
    configured: () => API.get('/api/repos/configured'),
    capacity: () => API.get('/api/repos/capacity'),
    add: (full_name, linked_account_id) => API.post('/api/repos/add', { full_name, linked_account_id }),
    create: (linked_account_id) => API.post('/api/repos/create', { linked_account_id }),
    remove: (id) => API.delete(`/api/repos/${id}`),
    toggle: (id, active) => API.post(`/api/repos/${id}/toggle`, { active }),
    org: () => API.get('/api/repos/org'),
    orgs: () => API.get('/api/repos/orgs'),
    setupOrg: (org, repoCount) => API.post('/api/repos/org/setup', { org, repoCount }),
    clearOrg: () => API.delete('/api/repos/org'),
    makePublic: () => API.post('/api/repos/make-public'),
  },

  cache: {
    stats: () => API.get('/api/cache/stats'),
    clear: () => API.delete('/api/cache'),
    setMaxGb: (maxGb) => API.patch('/api/cache/config', { maxGb }),
  },

  tasks: {
    list: (opts = {}) => {
      const params = new URLSearchParams();
      if (opts.resumable) params.set('resumable', '1');
      if (opts.active === false) params.set('active', '0');
      const qs = params.toString();
      return API.get(`/api/tasks${qs ? `?${qs}` : ''}`);
    },
    get: (id) => API.get(`/api/tasks/${id}`),
    pause: (id, reason) => API.post(`/api/tasks/${id}/pause`, reason ? { reason } : {}),
    resume: (id) => API.post(`/api/tasks/${id}/resume`),
    cancel: (id) => API.post(`/api/tasks/${id}/cancel`),
    dismiss: (id) => API.delete(`/api/tasks/${id}`),
    clearFailed: () => API.delete('/api/tasks/failed'),
  },
};

function driveBarClass(percent) {
  if (percent >= 90) return 'drive-bar-critical';
  if (percent >= 75) return 'drive-bar-warning';
  return 'drive-bar-healthy';
}

function renderDriveBar(vaultPercent, usedPercent) {
  const otherPercent = Math.max(0, usedPercent - vaultPercent);
  const cls = driveBarClass(usedPercent);
  return `
    <div class="drive-bar ${cls}">
      <div class="drive-bar-vault" style="width:${vaultPercent}%"></div>
      <div class="drive-bar-other" style="left:${vaultPercent}%;width:${otherPercent}%"></div>
    </div>
  `;
}

function formatSize(bytes) {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}

const UploadPrefs = {
  KEY: 'vault-upload-mode',
  get() {
    const mode = localStorage.getItem(this.KEY);
    return mode === 'git' ? 'git' : 'api';
  },
  set(mode) {
    localStorage.setItem(this.KEY, mode === 'git' ? 'git' : 'api');
  },
};

function getPreviewType(name, mimeType) {
  const ext = name.split('.').pop().toLowerCase();
  const images = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico', 'avif'];
  const videos = ['mp4', 'webm', 'mkv', 'avi', 'mov', 'm4v', 'ogv'];
  const audio = ['mp3', 'wav', 'ogg', 'flac', 'm4a', 'aac', 'opus'];
  const text = [
    'txt', 'md', 'markdown', 'json', 'xml', 'csv', 'log', 'js', 'ts', 'jsx', 'tsx',
    'py', 'rb', 'go', 'rs', 'java', 'css', 'scss', 'less', 'yaml', 'yml', 'toml',
    'ini', 'cfg', 'conf', 'sql', 'sh', 'bash', 'zsh', 'ps1', 'bat', 'dockerfile',
    'html', 'htm', 'c', 'cpp', 'h', 'hpp', 'cs', 'php', 'swift', 'kt', 'r', 'lua',
    'vue', 'svelte', 'env', 'gitignore', 'dockerignore',
  ];

  if (mimeType?.startsWith('image/') || images.includes(ext)) return 'image';
  if (mimeType?.startsWith('video/') || videos.includes(ext)) return 'video';
  if (mimeType?.startsWith('audio/') || audio.includes(ext)) return 'audio';
  if (mimeType === 'application/pdf' || ext === 'pdf') return 'pdf';
  if (mimeType === 'text/html' || ext === 'html' || ext === 'htm') return 'html';
  if (
    mimeType?.startsWith('text/')
    || mimeType === 'application/json'
    || mimeType === 'application/xml'
    || text.includes(ext)
  ) return 'text';
  return null;
}

function getMediaType(name, mimeType) {
  const type = getPreviewType(name, mimeType);
  return ['image', 'video', 'audio'].includes(type) ? type : null;
}

function getFileIcon(name, isFolder) {
  if (isFolder) return '📁';
  const ext = name.split('.').pop().toLowerCase();
  const icons = {
    pdf: '📄', doc: '📝', docx: '📝', txt: '📝', md: '📝',
    jpg: '🖼️', jpeg: '🖼️', png: '🖼️', gif: '🖼️', svg: '🖼️', webp: '🖼️',
    mp4: '🎬', mkv: '🎬', avi: '🎬', mov: '🎬',
    mp3: '🎵', wav: '🎵', flac: '🎵', ogg: '🎵',
    zip: '📦', rar: '📦', '7z': '📦', tar: '📦', gz: '📦',
    js: '💛', ts: '💙', py: '🐍', html: '🌐', css: '🎨',
    json: '📋', xml: '📋', csv: '📊',
    exe: '⚙️', dmg: '💿', iso: '💿',
  };
  return icons[ext] || '📄';
}
