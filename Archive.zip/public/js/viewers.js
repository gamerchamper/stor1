const LiveViewers = {
  active: false,
  eventSource: null,
  pollTimer: null,

  formatDuration(ms) {
    if (!ms || ms < 0) return '0s';
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  },

  formatLocation(geo) {
    if (!geo) return '—';
    const parts = [geo.city, geo.region, geo.country].filter(Boolean);
    return parts.length ? parts.join(', ') : 'Unknown';
  },

  formatCoords(geo) {
    if (!geo || geo.lat == null || geo.lon == null) return '';
    return `${geo.lat.toFixed(2)}, ${geo.lon.toFixed(2)}`;
  },

  parseUserAgent(ua) {
    if (!ua) return '—';
    if (/Edg\//.test(ua)) return 'Edge';
    if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) return 'Chrome';
    if (/Firefox\//.test(ua)) return 'Firefox';
    if (/Safari\//.test(ua) && !/Chrome/.test(ua)) return 'Safari';
    if (/OPR\//.test(ua)) return 'Opera';
    return ua.slice(0, 48) + (ua.length > 48 ? '…' : '');
  },

  escape(str) {
    const node = document.createElement('span');
    node.textContent = str || '';
    return node.innerHTML;
  },

  render(data) {
    const total = data?.totalViewers || 0;
    const shares = data?.activeShares || 0;

    document.getElementById('viewers-total').textContent = total;
    document.getElementById('viewers-shares').textContent = shares;

    const badge = document.getElementById('viewers-badge');
    if (badge) {
      badge.textContent = String(total);
      badge.classList.toggle('hidden', total === 0);
    }

    const empty = document.getElementById('viewers-empty');
    const list = document.getElementById('viewers-list');

    if (!data?.sessions?.length) {
      empty.classList.remove('hidden');
      list.innerHTML = '';
      return;
    }

    empty.classList.add('hidden');
    list.innerHTML = data.sessions.map((session) => this.renderSession(session)).join('');
  },

  renderSession(session) {
    const shareLabel = session.isFolder ? '📁' : '📄';
    const shareLink = session.shareUrl
      ? `<a href="${this.escape(session.shareUrl)}" target="_blank" rel="noopener">${this.escape(session.fileName)}</a>`
      : this.escape(session.fileName);

    const rows = session.viewers.map((viewer) => {
      const location = this.formatLocation(viewer.geo);
      const coords = this.formatCoords(viewer.geo);
      const isp = viewer.geo?.isp || '—';
      const ip = viewer.ip || '—';
      const browser = this.parseUserAgent(viewer.userAgent);
      const active = this.formatDuration(viewer.activeMs);
      const idle = viewer.idleMs < 5000 ? 'now' : `${Math.round(viewer.idleMs / 1000)}s ago`;

      return `
        <tr>
          <td>
            <div class="viewer-cell-name">
              <span class="viewer-avatar" style="background:${viewer.color}">${this.escape(viewer.initials)}</span>
              <span>${this.escape(viewer.name)}</span>
            </div>
          </td>
          <td><code class="viewer-ip">${this.escape(ip)}</code></td>
          <td>
            <div class="viewer-location">${this.escape(location)}</div>
            ${coords ? `<div class="viewer-coords">${this.escape(coords)}</div>` : ''}
          </td>
          <td>${this.escape(isp)}</td>
          <td><span class="viewer-active">${active}</span></td>
          <td>${idle}</td>
          <td title="${this.escape(viewer.userAgent || '')}">${this.escape(browser)}</td>
        </tr>
      `;
    }).join('');

    return `
      <section class="viewers-session">
        <div class="viewers-session-header">
          <div class="viewers-session-title">${shareLabel} ${shareLink}</div>
          <span class="viewers-session-count">${session.viewerCount} viewer${session.viewerCount === 1 ? '' : 's'}</span>
        </div>
        <div class="viewers-table-wrap">
          <table class="viewers-table">
            <thead>
              <tr>
                <th>Viewer</th>
                <th>IP</th>
                <th>Location</th>
                <th>ISP</th>
                <th>Active</th>
                <th>Last seen</th>
                <th>Browser</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </div>
      </section>
    `;
  },

  async refresh() {
    try {
      const data = await API.viewers.live();
      this.render(data);
    } catch (err) {
      console.error('Failed to load viewers', err);
    }
  },

  startStream() {
    this.stopStream();
    if (typeof EventSource === 'undefined') {
      this.pollTimer = setInterval(() => this.refresh(), 5000);
      this.refresh();
      return;
    }

    this.eventSource = new EventSource('/api/viewers/live/stream');
    this.eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.render(data);
      } catch { /* ignore */ }
    };
    this.eventSource.onerror = () => {
      this.stopStream();
      this.pollTimer = setInterval(() => this.refresh(), 5000);
      this.refresh();
    };
  },

  stopStream() {
    if (this.eventSource) {
      this.eventSource.close();
      this.eventSource = null;
    }
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
  },

  show() {
    this.active = true;
    document.getElementById('file-view').classList.add('hidden');
    document.getElementById('viewers-panel').classList.remove('hidden');
    document.querySelectorAll('.sidebar-item[data-view]').forEach((el) => {
      el.classList.toggle('active', el.dataset.view === 'viewers');
    });
    document.getElementById('btn-viewers')?.classList.add('active');
    this.startStream();
  },

  hide() {
    this.active = false;
    document.getElementById('viewers-panel').classList.add('hidden');
    document.getElementById('file-view').classList.remove('hidden');
    document.getElementById('btn-viewers')?.classList.remove('active');
    this.stopStream();
  },
};
