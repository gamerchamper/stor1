class Explorer {
  constructor() {
    this.currentPath = '/';
    this.files = [];
    this.selected = new Set();
    this.history = ['/'];
    this.historyIndex = 0;
    this.contextTarget = null;
    this.moveIds = [];
    this.moveDestination = '/';
    this.dragIds = null;
    this.contextMode = 'item';
    this.renamingId = null;
    this.accountView = 'primary';
  }

  displayName(file) {
    return DisplayNames.get(file.id, file.name);
  }

  positionContextMenu(menu, clientX, clientY) {
    menu.classList.remove('hidden');
    menu.style.left = `${clientX}px`;
    menu.style.top = `${clientY}px`;

    const rect = menu.getBoundingClientRect();
    const pad = 8;
    let left = clientX;
    let top = clientY;
    if (rect.right > window.innerWidth - pad) left = Math.max(pad, window.innerWidth - rect.width - pad);
    if (rect.bottom > window.innerHeight - pad) top = Math.max(pad, window.innerHeight - rect.height - pad);
    menu.style.left = `${left}px`;
    menu.style.top = `${top}px`;
  }

  setLoading(show) {
    document.getElementById('view-loading').classList.toggle('hidden', !show);
    document.getElementById('file-grid').style.opacity = show ? '0.5' : '1';
  }

  async navigate(path, { silent = false } = {}) {
    if (typeof App !== 'undefined' && App.showFilesPanel) App.showFilesPanel();
    this.currentPath = path;
    this.selected.clear();
    this.updateToolbar();

    if (!silent) this.setLoading(true);
    try {
      const data = await API.files.list(path, this.accountView);
      this.files = data.files;
      this.render();
      this.updateBreadcrumb();
      this.updateStatus();
    } catch (err) {
      App.toast(err.message, 'error');
    } finally {
      if (!silent) this.setLoading(false);
    }
  }

  async refresh({ filesOnly = false } = {}) {
    await this.navigate(this.currentPath, { silent: true });
    if (!filesOnly) await this.buildFolderTree();
  }

  goBack() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.navigate(this.history[this.historyIndex]);
    }
  }

  goUp() {
    if (this.currentPath === '/') return;
    const parts = this.currentPath.split('/').filter(Boolean);
    parts.pop();
    const newPath = parts.length ? '/' + parts.join('/') : '/';
    this.pushHistory(newPath);
    this.navigate(newPath);
  }

  pushHistory(path) {
    this.history = this.history.slice(0, this.historyIndex + 1);
    this.history.push(path);
    this.historyIndex = this.history.length - 1;
    document.getElementById('btn-back').disabled = this.historyIndex <= 0;
  }

  openItem(file) {
    if (file.is_folder) {
      this.pushHistory(file.path);
      this.navigate(file.path);
    } else if (!Viewer.open(file)) {
      this.downloadFile(file);
    }
  }

  fileItemClass(file, { settled = true } = {}) {
    return 'file-item'
      + (settled ? ' file-item-settled' : '')
      + (this.selected.has(file.id) ? ' selected' : '')
      + (file.pending ? ' pending' : '');
  }

  fileItemHtml(file) {
    const isPending = !!file.pending;
    const thumbSrc = file.has_thumbnail
      ? `/api/files/thumbnail/${file.id}${file.thumbVersion ? `?v=${file.thumbVersion}` : ''}`
      : '';
    const iconHtml = !isPending && file.has_thumbnail
      ? `<img class="file-thumb" src="${thumbSrc}" alt="" loading="lazy">`
      : `<div class="file-icon">${isPending ? '⏳' : getFileIcon(file.name, file.is_folder)}</div>`;

    const uploadBar = isPending ? `
      <div class="file-upload-bar"><div class="file-upload-bar-fill" style="width:${file.uploadPercent || 0}%"></div></div>
      <div class="file-size">${this.escape(file.uploadStatus || 'Uploading...')}</div>
    ` : (!file.is_folder ? `<div class="file-size">${formatSize(file.size)}</div>` : '');

    const label = this.displayName(file);
    const title = label !== file.name ? file.name : '';

    let viewBadge = '';
    if (this.accountView !== 'primary' && !file.is_folder && file.view_status && file.view_status !== 'folder') {
      if (file.view_status === 'synced') {
        viewBadge = '<span class="view-badge synced" title="Fully available in this view">✓</span>';
      } else if (file.view_status === 'partial') {
        viewBadge = `<span class="view-badge partial" title="Partially available">${file.view_chunks_available || 0}/${file.view_chunks_total || 0}</span>`;
      }
    }

    return `
      ${iconHtml}
      <div class="file-name"${title ? ` title="${this.escape(title)}"` : ''}>${this.escape(label)}${viewBadge}</div>
      ${uploadBar}
    `;
  }

  bindFileItem(el, file) {
    if (file.pending) return;
    el.onclick = (e) => this.handleClick(e, file);
    el.ondblclick = (e) => {
      if (this.renamingId || e.target.closest('.file-rename-input')) return;
      this.openItem(file);
    };
    el.oncontextmenu = (e) => this.showContextMenu(e, file);
    el.draggable = true;
    el.addEventListener('dragstart', (e) => this.handleDragStart(e, file));
    el.addEventListener('dragend', () => this.handleDragEnd());
    if (file.is_folder) this.bindFolderDropTarget(el, file);
  }

  getMoveIds(file) {
    return this.selected.has(file.id) ? [...this.selected] : [file.id];
  }

  handleDragStart(e, file) {
    const ids = this.getMoveIds(file);
    this.dragIds = ids;
    e.dataTransfer.setData('application/x-vault-move', JSON.stringify(ids));
    e.dataTransfer.effectAllowed = 'move';
    e.currentTarget.classList.add('dragging');
  }

  handleDragEnd() {
    this.dragIds = null;
    document.querySelectorAll('.file-item.dragging, .file-item.drop-target').forEach((el) => {
      el.classList.remove('dragging', 'drop-target');
    });
  }

  bindFolderDropTarget(el, folder) {
    el.addEventListener('dragover', (e) => {
      if (!e.dataTransfer.types.includes('application/x-vault-move')) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'move';
      el.classList.add('drop-target');
    });
    el.addEventListener('dragleave', (e) => {
      if (!el.contains(e.relatedTarget)) el.classList.remove('drop-target');
    });
    el.addEventListener('drop', async (e) => {
      if (!e.dataTransfer.types.includes('application/x-vault-move')) return;
      e.preventDefault();
      e.stopPropagation();
      el.classList.remove('drop-target');
      const ids = JSON.parse(e.dataTransfer.getData('application/x-vault-move') || '[]');
      await this.moveItems(ids, folder.path);
    });
  }

  createFileElement(file) {
    const el = document.createElement('div');
    el.className = this.fileItemClass(file, { settled: false });
    el.dataset.id = file.id;
    el.innerHTML = this.fileItemHtml(file);
    this.bindFileItem(el, file);
    return el;
  }

  updateFileElement(el, file) {
    el.className = this.fileItemClass(file);
    if (file.pending) {
      const fill = el.querySelector('.file-upload-bar-fill');
      const statusEl = el.querySelector('.file-size');
      if (fill) fill.style.width = `${file.uploadPercent || 0}%`;
      if (statusEl) statusEl.textContent = file.uploadStatus || 'Uploading...';
      return;
    }
    el.innerHTML = this.fileItemHtml(file);
    this.bindFileItem(el, file);
  }

  updateSelectionClasses() {
    document.querySelectorAll('#file-grid .file-item').forEach((el) => {
      el.classList.toggle('selected', this.selected.has(el.dataset.id));
    });
  }

  render() {
    const grid = document.getElementById('file-grid');
    const empty = document.getElementById('empty-state');

    if (this.files.length === 0) {
      grid.replaceChildren();
      empty.classList.remove('hidden');
      return;
    }
    empty.classList.add('hidden');

    const existing = new Map(
      [...grid.querySelectorAll('.file-item')].map((el) => [el.dataset.id, el])
    );
    const fragment = document.createDocumentFragment();

    for (const file of this.files) {
      let el = existing.get(file.id);
      if (el) {
        existing.delete(file.id);
        this.updateFileElement(el, file);
      } else {
        el = this.createFileElement(file);
      }
      fragment.appendChild(el);
    }

    for (const el of existing.values()) el.remove();
    grid.appendChild(fragment);
  }

  handleClick(e, file) {
    if (e.ctrlKey || e.metaKey) {
      if (this.selected.has(file.id)) this.selected.delete(file.id);
      else this.selected.add(file.id);
    } else {
      this.selected.clear();
      this.selected.add(file.id);
    }
    this.updateSelectionClasses();
    this.updateToolbar();
    this.updateStatus();
  }

  updateBreadcrumb() {
    const bc = document.getElementById('breadcrumb');
    bc.innerHTML = '';

    const parts = this.currentPath === '/' ? [] : this.currentPath.split('/').filter(Boolean);
    const items = [{ name: 'Home', path: '/' }, ...parts.map((p, i) => ({
      name: p,
      path: '/' + parts.slice(0, i + 1).join('/'),
    }))];

    items.forEach((item, i) => {
      if (i > 0) {
        const sep = document.createElement('span');
        sep.className = 'breadcrumb-sep';
        sep.textContent = '›';
        bc.appendChild(sep);
      }
      const el = document.createElement('span');
      el.className = 'breadcrumb-item';
      el.textContent = item.name;
      el.addEventListener('click', () => {
        this.pushHistory(item.path);
        this.navigate(item.path);
      });
      bc.appendChild(el);
    });

    document.getElementById('btn-up').disabled = this.currentPath === '/';
  }

  updateStatus() {
    const total = this.files.length;
    const folders = this.files.filter(f => f.is_folder).length;
    const files = total - folders;
    document.getElementById('status-items').textContent =
      `${total} item${total !== 1 ? 's' : ''} (${folders} folder${folders !== 1 ? 's' : ''}, ${files} file${files !== 1 ? 's' : ''})`;

    if (this.selected.size > 0) {
      const selectedFiles = this.files.filter(f => this.selected.has(f.id) && !f.is_folder);
      const size = selectedFiles.reduce((s, f) => s + f.size, 0);
      document.getElementById('status-selected').textContent =
        `${this.selected.size} selected`;
      document.getElementById('status-size').textContent =
        selectedFiles.length ? formatSize(size) : '';
    } else {
      document.getElementById('status-selected').textContent = '';
      document.getElementById('status-size').textContent = '';
    }
  }

  updateToolbar() {
    const hasSelection = this.selected.size > 0;
    const selectedFiles = this.files.filter(f => this.selected.has(f.id));
    const hasFiles = selectedFiles.some(f => !f.is_folder);
    const singleFolder = selectedFiles.length === 1 && selectedFiles[0].is_folder;

    document.getElementById('btn-download').disabled = !hasFiles;
    document.getElementById('btn-move').disabled = !hasSelection;
    document.getElementById('btn-delete').disabled = !hasSelection;

    const openItem = document.querySelector('[data-action="open"]');
    if (openItem) openItem.style.display = singleFolder ? '' : 'none';
  }

  async downloadFile(file) {
    await DownloadManager.downloadFile(file, { view: this.accountView });
  }

  async downloadSelected() {
    const files = this.files.filter(f => this.selected.has(f.id) && !f.is_folder);
    for (const file of files) {
      await this.downloadFile(file);
    }
  }

  async refreshThumbnail(file) {
    if (!file || file.is_folder) return;
    try {
      App.toast(`Refreshing thumbnail for ${file.name}...`);
      await API.files.refreshThumbnail(file.id);
      file.has_thumbnail = 1;
      file.thumbVersion = Date.now();
      const el = document.querySelector(`#file-grid .file-item[data-id="${file.id}"] img.file-thumb`);
      if (el) el.src = `/api/files/thumbnail/${file.id}?v=${file.thumbVersion}`;
      App.toast(`Thumbnail updated for ${file.name}`, 'success');
      await this.refresh({ filesOnly: true });
    } catch (err) {
      let msg = err.message || 'Refresh failed';
      if (msg === 'Not Found') {
        msg = 'Refresh endpoint not found — hard-refresh the page (Ctrl+Shift+R) and ensure the server is running';
      } else if (msg === 'Could not find or generate a thumbnail for this file') {
        msg = 'No cover art found for this file — try renaming it (e.g. "Show Name - Episode") or use a smaller file';
      }
      App.toast(msg, 'error');
    }
  }

  async deleteSelected() {
    const ids = [...this.selected];
    if (!ids.length) return;
    if (!confirm(`Delete ${ids.length} item(s)? This removes chunks from GitHub repos.`)) return;

    const deleteBtn = document.getElementById('btn-delete');
    App.setButtonLoading(deleteBtn, true);

    document.querySelectorAll('.file-item').forEach(el => {
      if (ids.includes(el.dataset.id)) el.classList.add('removing');
    });

    try {
      const { taskId } = await API.files.deleteBatch(ids);
      TaskPanel.track(taskId);
      DisplayNames.removeMany(ids);
      this.selected.clear();
      this.updateToolbar();
    } catch (err) {
      document.querySelectorAll('.file-item.removing').forEach((el) => {
        el.classList.remove('removing');
      });
      App.toast(`Failed to delete: ${err.message}`, 'error');
    }

    App.setButtonLoading(deleteBtn, false);
  }

  showContextMenu(e, file) {
    e.preventDefault();
    e.stopPropagation();
    this.contextMode = 'item';
    this.contextTarget = file;
    if (!this.selected.has(file.id)) {
      this.selected.clear();
      this.selected.add(file.id);
      this.updateSelectionClasses();
      this.updateToolbar();
    }

    const menu = document.getElementById('context-menu');
    document.getElementById('context-item-actions').classList.remove('hidden');
    document.getElementById('context-blank-actions').classList.add('hidden');

    const openItem = menu.querySelector('[data-action="open"]');
    const previewItem = menu.querySelector('[data-action="preview"]');
    const renameItem = menu.querySelector('[data-action="rename"]');
    const previewType = !file.is_folder && getPreviewType(file.name, file.mime_type);

    openItem.style.display = file.is_folder ? '' : 'none';
    previewItem.style.display = previewType ? '' : 'none';
    previewItem.textContent = previewType === 'video' ? 'Play' : 'Preview';
    renameItem.style.display = this.selected.size === 1 ? '' : 'none';

    const dlItem = menu.querySelector('[data-action="download"]');
    const detailsItem = menu.querySelector('[data-action="details"]');
    const shareItem = menu.querySelector('[data-action="share"]');
    const thumbItem = menu.querySelector('[data-action="refresh-thumb"]');
    dlItem.style.display = file.is_folder ? 'none' : '';
    detailsItem.style.display = file.is_folder ? 'none' : '';
    shareItem.style.display = '';
    if (thumbItem) thumbItem.style.display = file.is_folder ? 'none' : '';

    this.positionContextMenu(menu, e.clientX, e.clientY);
  }

  showBlankContextMenu(e) {
    e.preventDefault();
    e.stopPropagation();
    this.contextMode = 'blank';
    this.contextTarget = null;

    const menu = document.getElementById('context-menu');
    document.getElementById('context-item-actions').classList.add('hidden');
    document.getElementById('context-blank-actions').classList.remove('hidden');
    this.positionContextMenu(menu, e.clientX, e.clientY);
  }

  hideContextMenu() {
    document.getElementById('context-menu').classList.add('hidden');
    this.contextMode = 'item';
  }

  startRename(file) {
    if (!file || file.pending) return;
    const el = document.getElementById('file-grid')?.querySelector(`.file-item[data-id="${file.id}"]`);
    if (!el) return;

    const nameEl = el.querySelector('.file-name');
    if (!nameEl || nameEl.querySelector('.file-rename-input')) return;

    this.renamingId = file.id;
    el.classList.add('renaming');

    const current = this.displayName(file);
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'file-rename-input';
    input.value = current;

    let cancelled = false;

    const finish = () => {
      if (!cancelled) {
        const next = input.value.trim();
        if (next && next !== file.name) DisplayNames.set(file.id, next);
        else DisplayNames.remove(file.id);
      }
      this.renamingId = null;
      el.classList.remove('renaming');
      this.render();
      if (file.is_folder) this.buildFolderTree();
    };

    input.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') {
        ev.preventDefault();
        input.blur();
      }
      if (ev.key === 'Escape') {
        ev.preventDefault();
        cancelled = true;
        this.renamingId = null;
        el.classList.remove('renaming');
        nameEl.textContent = current;
      }
    });
    input.addEventListener('blur', finish, { once: true });
    input.addEventListener('click', (ev) => ev.stopPropagation());

    nameEl.replaceChildren(input);
    input.focus();
    input.select();
  }

  async moveItems(ids, destination) {
    const uniqueIds = [...new Set((ids || []).filter(Boolean))];
    if (!uniqueIds.length) return;

    try {
      const result = await API.files.move(uniqueIds, destination);
      if (result.moved === 0) {
        App.toast('Items are already in that folder', 'info');
        return;
      }
      const label = result.moved === 1 ? '1 item moved' : `${result.moved} items moved`;
      App.toast(label, 'success');
      this.selected.clear();
      this.updateToolbar();
      await this.refresh();
    } catch (err) {
      App.toast(err.message, 'error');
    }
  }

  async showMoveDialog(ids) {
    const uniqueIds = [...new Set((ids || []).filter(Boolean))];
    if (!uniqueIds.length) return;

    this.moveIds = uniqueIds;
    this.moveDestination = '/';

    const desc = document.getElementById('move-modal-desc');
    desc.textContent = uniqueIds.length === 1
      ? 'Choose where to move this item.'
      : `Choose where to move ${uniqueIds.length} items.`;

    const picker = document.getElementById('move-folder-picker');
    picker.innerHTML = '<div class="folder-picker-item selected" data-path="/"><span>🏠</span> Home</div>';

    const homeItem = picker.querySelector('[data-path="/"]');
    homeItem.addEventListener('click', () => this.selectMoveDestination('/', picker));

    try {
      const allFolders = await this.getAllFolders('/');
      const excluded = await this.getExcludedMoveDestinations(uniqueIds);
      this.renderMovePicker(picker, allFolders, excluded);
    } catch {
      // Home-only picker is still usable
    }

    document.getElementById('btn-confirm-move').disabled = false;
    document.getElementById('move-modal').classList.remove('hidden');
  }

  async getExcludedMoveDestinations(ids) {
    const excluded = new Set();
    for (const id of ids) {
      let file = this.files.find((entry) => entry.id === id);
      if (!file) {
        const data = await API.files.details(id).catch(() => null);
        file = data?.file;
      }
      if (!file?.is_folder) continue;
      excluded.add(file.path);
      const descendants = await this.getAllFolders(file.path);
      this.collectFolderPaths(descendants, excluded);
    }
    return excluded;
  }

  collectFolderPaths(folders, paths) {
    for (const folder of folders) {
      paths.add(folder.path);
      if (folder.children?.length) this.collectFolderPaths(folder.children, paths);
    }
  }

  selectMoveDestination(path, picker) {
    this.moveDestination = path;
    picker.querySelectorAll('.folder-picker-item').forEach((el) => {
      el.classList.toggle('selected', el.dataset.path === path);
    });
    document.getElementById('btn-confirm-move').disabled = false;
  }

  renderMovePicker(container, folders, excludedPaths) {
    for (const folder of folders) {
      const el = document.createElement('div');
      const disabled = excludedPaths.has(folder.path);
      el.className = `folder-picker-item${disabled ? ' disabled' : ''}`;
      el.dataset.path = folder.path;
      el.style.paddingLeft = `${12 + (folder.depth || 0) * 12}px`;
      el.innerHTML = `<span>📁</span> ${this.escape(folder.name)}`;
      if (!disabled) {
        el.addEventListener('click', () => this.selectMoveDestination(folder.path, container));
      }
      container.appendChild(el);

      if (folder.children?.length) {
        this.renderMovePicker(container, folder.children.map((child) => ({
          ...child,
          depth: (folder.depth || 0) + 1,
        })), excludedPaths);
      }
    }
  }

  async confirmMove() {
    const btn = document.getElementById('btn-confirm-move');
    App.setButtonLoading(btn, true);
    try {
      await this.moveItems(this.moveIds, this.moveDestination);
      document.getElementById('move-modal').classList.add('hidden');
    } finally {
      App.setButtonLoading(btn, false);
    }
  }

  async buildFolderTree() {
    const tree = document.getElementById('folder-tree');
    tree.innerHTML = '';

    try {
      const allFolders = await this.getAllFolders('/');
      this.renderTree(tree, allFolders, '/');
    } catch {
      // tree is optional
    }
  }

  async getAllFolders(path, depth = 0) {
    const data = await API.files.list(path);
    const folders = data.files.filter(f => f.is_folder);
    const result = [];
    for (const folder of folders) {
      const children = await this.getAllFolders(folder.path, depth + 1);
      result.push({ ...folder, children, depth });
    }
    return result;
  }

  renderTree(container, folders, basePath) {
    for (const folder of folders) {
      const el = document.createElement('div');
      el.className = 'tree-item';
      el.innerHTML = `<span>📁</span> ${this.escape(this.displayName(folder))}`;
      el.addEventListener('click', () => {
        this.pushHistory(folder.path);
        this.navigate(folder.path);
      });
      container.appendChild(el);
      if (folder.children?.length) {
        const childContainer = document.createElement('div');
        childContainer.style.paddingLeft = '12px';
        this.renderTree(childContainer, folder.children, folder.path);
        container.appendChild(childContainer);
      }
    }
  }

  updatePendingProgress(pendingId, percent, status) {
    const item = this.files.find((f) => f.id === pendingId);
    if (!item) return;

    item.uploadPercent = percent;
    item.uploadStatus = status;

    const el = document.getElementById('file-grid')?.querySelector(`[data-id="${pendingId}"]`);
    if (el) {
      const fill = el.querySelector('.file-upload-bar-fill');
      const statusEl = el.querySelector('.file-size');
      if (fill) fill.style.width = `${percent}%`;
      if (statusEl) statusEl.textContent = status;
      return;
    }

    this.render();
  }

  escape(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
}
