const ShareClientStream = {
  token: null,
  fileId: null,
  manifest: null,
  fileKey: null,
  chunks: null,
  completed: 0,
  pool: null,
  abortController: null,
  blobUrl: null,
  cachedEntry: null,
  cacheHit: false,
  offline: false,
  serverOffline: false,

  manifestUrl(token, fileId) {
    const qs = fileId ? `?file=${encodeURIComponent(fileId)}` : '';
    return `/api/public/share/${token}/manifest${qs}`;
  },

  chunkUrl(index) {
    const qs = new URLSearchParams();
    if (this.fileId) qs.set('file', this.fileId);
    return `/api/public/share/${this.token}/chunk/${index}?${qs.toString()}`;
  },

  blobType() {
    const mime = this.manifest?.mime_type || '';
    if (mime && mime !== 'application/octet-stream') return mime;
    const ext = (this.manifest?.name || '').split('.').pop().toLowerCase();
    const map = {
      mp4: 'video/mp4',
      m4v: 'video/mp4',
      mov: 'video/quicktime',
      webm: 'video/webm',
      mkv: 'video/x-matroska',
      mp3: 'audio/mpeg',
      m4a: 'audio/mp4',
      wav: 'audio/wav',
      ogg: 'audio/ogg',
      flac: 'audio/flac',
      jpg: 'image/jpeg',
      jpeg: 'image/jpeg',
      png: 'image/png',
      gif: 'image/gif',
      webp: 'image/webp',
    };
    return map[ext] || 'application/octet-stream';
  },

  cacheKey() {
    return ShareMediaCache.cacheKey(this.token, this.fileId);
  },

  cacheFingerprint() {
    return ShareMediaCache.fingerprint(this.manifest);
  },

  hasCachedBlob() {
    return !!this.cachedEntry?.blob;
  },

  async fetchManifestFromNetwork() {
    const res = await fetch(this.manifestUrl(this.token, this.fileId), {
      signal: this.abortController.signal,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'Failed to load share manifest');
    }
    return res.json();
  },

  async restoreCachedChunks() {
    const total = this.manifest?.chunks?.length || 0;
    for (let i = 0; i < total; i++) {
      const dec = await ShareMediaCache.getChunk(this.cacheKey(), i);
      if (dec) {
        this.chunks[i] = dec;
        continue;
      }
      const enc = await ShareMediaCache.getEncChunk(this.cacheKey(), i);
      if (enc && this.fileKey) {
        try {
          const meta = this.manifest.chunks[i];
          this.chunks[i] = await ShareCrypto.decryptChunk(enc, this.fileKey, meta.iv, meta.tag);
        } catch { /* skip bad cache */ }
      }
    }
    this.syncCompleted();
  },

  async load(token, fileId, onProgress) {
    this.abort();
    this.token = token;
    this.fileId = fileId;
    this.onProgress = onProgress || (() => {});
    this.abortController = new AbortController();
    this.chunks = [];
    this.completed = 0;
    this.cachedEntry = null;
    this.cacheHit = false;
    this.offline = false;
    this.serverOffline = false;

    const mediaKey = this.cacheKey();
    const offlineEntry = await ShareMediaCache.getManifest(mediaKey);

    let manifest = null;
    try {
      manifest = await this.fetchManifestFromNetwork();
      await ShareMediaCache.putManifest(mediaKey, {
        manifest,
        token,
        fileId,
      });
    } catch {
      if (offlineEntry?.manifest) {
        manifest = offlineEntry.manifest;
        this.offline = true;
        this.serverOffline = true;
      }
    }

    if (!manifest) {
      throw new Error('Share unavailable offline — open this link once while the server is online');
    }

    this.manifest = manifest;
    if (!this.manifest.client_stream) {
      throw new Error('Client-side streaming is not enabled for this share');
    }
    if (!this.manifest.share_key || !this.manifest.chunks?.length) {
      throw new Error('Share manifest missing encryption data');
    }

    const fingerprint = this.cacheFingerprint();
    this.cachedEntry = await ShareMediaCache.getMedia(mediaKey, fingerprint);
    if (this.cachedEntry?.blob) {
      this.cacheHit = true;
      this.completed = this.manifest.chunks.length;
      this.onProgress(this.getStatus());
      return this.manifest;
    }

    await this.restoreCachedChunks();

    this.fileKey = await ShareCrypto.unwrapFileKey(this.manifest.share_key, token);

    if (this.completed < this.manifest.chunks.length) {
      await this.restoreCachedChunks();
    }

    if (this.completed >= this.manifest.chunks.length) {
      this.cacheHit = false;
      this.onProgress(this.getStatus());
    }

    const chunkCount = this.manifest.chunks.length;
    this.pool = AdaptiveConcurrency.createPool(chunkCount, { max: 16, initial: 8 });
    this.pool.start();
    this.onProgress(this.getStatus());
    return this.manifest;
  },

  getStatus() {
    const total = this.manifest?.chunks?.length || 0;
    const bytesReady = this.cacheHit
      ? (this.manifest?.size || 0)
      : this.contiguousBytesReady();
    const done = this.cacheHit || (this.completed >= total && total > 0);
    let stage = 'fetching';
    if (this.cacheHit) stage = 'cached';
    else if (this.offline) stage = 'offline';
    else if (done) stage = 'ready';
    else if (this.completed > 0) stage = 'decrypting';

    return {
      stage,
      segments: this.cacheHit ? total : this.completed,
      total_segments: total,
      bytes_ready: bytesReady,
      progress: done && total > 0 ? 100 : (total > 0 ? Math.round((this.completed / total) * 100) : 0),
      mode: 'client',
      ready: done,
      buffered: done,
      client_stream: true,
      cache_hit: this.cacheHit,
      offline: this.offline,
    };
  },

  contiguousBytesReady() {
    if (!this.manifest?.chunks) return 0;
    let ready = 0;
    for (let i = 0; i < this.manifest.chunks.length; i++) {
      if (!this.chunks[i]) break;
      ready += this.manifest.chunks[i].plain_size;
    }
    return ready;
  },

  syncCompleted() {
    this.completed = this.chunks.filter(Boolean).length;
  },

  async readCachedEncrypted(index) {
    const enc = await ShareMediaCache.getEncChunk(this.cacheKey(), index);
    if (enc) return enc;

    if (typeof caches !== 'undefined') {
      for (const name of ['vault-share-v3', 'vault-share-v2']) {
        try {
          const cache = await caches.open(name);
          const cached = await cache.match(this.chunkUrl(index));
          if (cached?.ok) {
            const buf = await cached.arrayBuffer();
            ShareMediaCache.putEncChunk(this.cacheKey(), index, buf).catch(() => {});
            return buf;
          }
        } catch { /* try next cache */ }
      }
    }
    return null;
  },

  chunkSourceUrls(meta) {
    const urls = [];
    if (meta.raw_url) urls.push(meta.raw_url);
    if (meta.repo && meta.repo_path) {
      const [owner, repo] = meta.repo.split('/');
      const branch = meta.branch || 'main';
      const path = meta.repo_path.split('/').map(encodeURIComponent).join('/');
      urls.push(`https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${path}`);
    }
    return [...new Set(urls.filter(Boolean))];
  },

  usesDirectFetch() {
    return this.manifest?.direct_fetch !== false;
  },

  async fetchFromGithub(urls) {
    for (const url of urls) {
      try {
        const res = await fetch(url, { signal: this.abortController.signal });
        if (res.ok) return res.arrayBuffer();
      } catch { /* try next source */ }
    }
    return null;
  },

  async fetchEncryptedChunk(index, meta) {
    const cached = await this.readCachedEncrypted(index);
    if (cached) return cached;

    const urls = this.chunkSourceUrls(meta);
    if (this.usesDirectFetch() && urls.length) {
      const direct = await this.fetchFromGithub(urls);
      if (direct) {
        ShareMediaCache.putEncChunk(this.cacheKey(), index, direct).catch(() => {});
        return direct;
      }
    }

    if (!this.serverOffline) {
      try {
        const res = await fetch(this.chunkUrl(index), {
          signal: this.abortController.signal,
        });
        if (res.ok) {
          const buf = await res.arrayBuffer();
          ShareMediaCache.putEncChunk(this.cacheKey(), index, buf).catch(() => {});
          return buf;
        }
        if (res.status >= 500 || res.status === 0) {
          this.serverOffline = true;
          this.offline = true;
        }
      } catch {
        this.serverOffline = true;
        this.offline = true;
      }
    } else {
      this.offline = true;
    }

    const retryCached = await this.readCachedEncrypted(index);
    if (retryCached) return retryCached;

    if (!this.usesDirectFetch() && urls.length) {
      const direct = await this.fetchFromGithub(urls);
      if (direct) {
        ShareMediaCache.putEncChunk(this.cacheKey(), index, direct).catch(() => {});
        return direct;
      }
    }

    throw new Error(
      this.manifest?.all_repos_public === false
        ? `Chunk ${index} unavailable — make storage repos public in Storage Repositories, or keep the server running`
        : `Chunk ${index} not available — keep the page open while the server is running to cache more`
    );
  },

  async fetchOne(index) {
    if (this.chunks[index]) return this.chunks[index];
    if (!this.manifest?.chunks[index]) throw new Error(`Unknown chunk ${index}`);

    await this.pool.acquire();
    try {
      if (this.chunks[index]) return this.chunks[index];

      const cached = await ShareMediaCache.getChunk(this.cacheKey(), index);
      if (cached) {
        this.chunks[index] = cached;
        this.syncCompleted();
        this.onProgress(this.getStatus());
        return cached;
      }

      const meta = this.manifest.chunks[index];
      const enc = await this.fetchEncryptedChunk(index, meta);
      const dec = await ShareCrypto.decryptChunk(enc, this.fileKey, meta.iv, meta.tag);
      this.chunks[index] = dec;
      this.syncCompleted();
      this.pool.recordBytes(dec.byteLength || dec.length);
      ShareMediaCache.putChunk(this.cacheKey(), index, dec).catch(() => {});
      this.onProgress(this.getStatus());
      return dec;
    } finally {
      this.pool.release();
    }
  },

  buildFullBlob() {
    const total = this.manifest.chunks.length;
    let size = 0;
    for (let i = 0; i < total; i++) {
      const chunk = this.chunks[i];
      if (!chunk) throw new Error(`Missing chunk ${i}`);
      size += chunk.byteLength || chunk.length;
    }

    const expected = this.manifest?.size;
    if (expected > 0 && size !== expected) {
      throw new Error(`Decrypted file size mismatch (${size} vs ${expected} bytes)`);
    }

    const out = new Uint8Array(size);
    let offset = 0;
    for (let i = 0; i < total; i++) {
      const chunk = this.chunks[i];
      out.set(chunk, offset);
      offset += chunk.byteLength || chunk.length;
    }

    this.validateDecryptedFile(out);
    return new Blob([out], { type: this.blobType() });
  },

  validateDecryptedFile(bytes) {
    if (!bytes?.length) throw new Error('Decrypted file is empty');

    const ext = (this.manifest?.name || '').split('.').pop().toLowerCase();
    const mime = this.manifest?.mime_type || '';

    if (mime.startsWith('image/') || ['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
      const isJpeg = bytes[0] === 0xff && bytes[1] === 0xd8;
      const isPng = bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47;
      const isGif = bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46;
      const isWebp = bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50;
      if (!isJpeg && !isPng && !isGif && !isWebp) {
        throw new Error('Decrypted data does not look like a valid image');
      }
      return;
    }

    if (mime.startsWith('video/') || mime.startsWith('audio/') || ['mp4', 'm4v', 'mov', 'webm', 'mkv', 'mp3', 'm4a', 'wav', 'ogg', 'flac'].includes(ext)) {
      const box = String.fromCharCode(bytes[4], bytes[5], bytes[6], bytes[7]);
      const isMp4 = box === 'ftyp';
      const isWebm = bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3;
      const isId3 = bytes[0] === 0x49 && bytes[1] === 0x44 && bytes[2] === 0x33;
      const isMp3Frame = bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0;
      const isWav = bytes[0] === 0x52 && bytes[1] === 0x69 && bytes[2] === 0x46 && bytes[3] === 0x46;
      const isOgg = bytes[0] === 0x4f && bytes[1] === 0x67 && bytes[2] === 0x67 && bytes[3] === 0x53;
      const isFlac = bytes[0] === 0x66 && bytes[1] === 0x4c && bytes[2] === 0x61 && bytes[3] === 0x43;

      if (['mp4', 'm4v', 'mov', 'm4a'].includes(ext) && !isMp4) {
        throw new Error('Decrypted file does not look like a valid MP4');
      }
      if (ext === 'webm' && !isWebm) {
        throw new Error('Decrypted file does not look like a valid WebM');
      }
      if (ext === 'mp3' && !isId3 && !isMp3Frame) {
        throw new Error('Decrypted file does not look like a valid MP3');
      }
      if (ext === 'wav' && !isWav) {
        throw new Error('Decrypted file does not look like a valid WAV');
      }
      if (ext === 'ogg' && !isOgg) {
        throw new Error('Decrypted file does not look like a valid OGG');
      }
      if (ext === 'flac' && !isFlac) {
        throw new Error('Decrypted file does not look like a valid FLAC');
      }
    }
  },

  prepareMediaElement(mediaEl, wrap) {
    if (wrap) wrap.classList.remove('hidden');
    mediaEl.preload = 'auto';
    mediaEl.playsInline = true;
  },

  resolvedBlob() {
    if (this.cachedEntry?.blob) return this.cachedEntry.blob;
    return this.buildFullBlob();
  },

  setBlobUrl(el) {
    this.revokeBlobUrl();
    const blob = this.resolvedBlob();
    this.blobUrl = URL.createObjectURL(blob);
    el.src = this.blobUrl;
    return this.blobUrl;
  },

  saveToCache(blob) {
    if (!blob || this.cacheHit) return;
    ShareMediaCache.putMedia(this.cacheKey(), this.cacheFingerprint(), blob, {
      mimeType: this.blobType(),
      name: this.manifest?.name || '',
      token: this.token,
      fileId: this.fileId,
    }).catch(() => {});
  },

  revokeBlobUrl() {
    if (this.blobUrl) {
      URL.revokeObjectURL(this.blobUrl);
      this.blobUrl = null;
    }
  },

  waitForMediaReady(mediaEl, timeoutMs = 120000) {
    return new Promise((resolve, reject) => {
      const hasDuration = () => Number.isFinite(mediaEl.duration) && mediaEl.duration > 0;

      const tryResolve = () => {
        if (mediaEl.error) {
          onErr();
          return;
        }
        if (mediaEl.readyState >= 1 && hasDuration()) {
          done();
        }
      };

      if (mediaEl.readyState >= 1 && hasDuration()) {
        resolve();
        return;
      }

      const timer = setTimeout(() => {
        cleanup();
        if (mediaEl.error) {
          onErr();
          return;
        }
        if (hasDuration()) {
          resolve();
          return;
        }
        reject(new Error('Media failed to load — file may be unsupported in this browser'));
      }, timeoutMs);

      const done = () => {
        clearTimeout(timer);
        cleanup();
        resolve();
      };

      const onErr = () => {
        clearTimeout(timer);
        cleanup();
        const code = mediaEl.error?.code;
        const msg = code === 4 ? 'Format not supported by this browser'
          : code === 3 ? 'Media decode failed'
            : 'Media failed to load';
        reject(new Error(msg));
      };

      const cleanup = () => {
        mediaEl.removeEventListener('loadedmetadata', tryResolve);
        mediaEl.removeEventListener('durationchange', tryResolve);
        mediaEl.removeEventListener('canplay', tryResolve);
        mediaEl.removeEventListener('error', onErr);
      };

      mediaEl.addEventListener('loadedmetadata', tryResolve);
      mediaEl.addEventListener('durationchange', tryResolve);
      mediaEl.addEventListener('canplay', tryResolve);
      mediaEl.addEventListener('error', onErr);
    });
  },

  async fetchAllParallel(onProgress) {
    if (onProgress) this.onProgress = onProgress;
    if (this.cacheHit) return this.resolvedBlob();

    const indices = this.manifest.chunks.map((_, i) => i);
    const results = await Promise.allSettled(indices.map((index) => this.fetchOne(index)));
    const missing = indices.filter((i) => !this.chunks[i]);
    if (missing.length > 0) {
      const firstFail = results.find((r) => r.status === 'rejected');
      throw firstFail?.reason || new Error(
        `${missing.length} chunk(s) not cached yet (e.g. ${missing[0]}) — keep the page open while the server is running`
      );
    }

    const blob = this.buildFullBlob();
    this.saveToCache(blob);
    return blob;
  },

  async playMedia(mediaEl, wrap = null) {
    await this.fetchAllParallel();

    this.prepareMediaElement(mediaEl, wrap);
    this.setBlobUrl(mediaEl);
    mediaEl.load();
    await this.waitForMediaReady(mediaEl);
    await mediaEl.play().catch(() => {});
  },

  async playWithMse(mediaEl, wrap = null) {
    return this.playMedia(mediaEl, wrap);
  },

  async playWithBlob(mediaEl, wrap = null) {
    return this.playMedia(mediaEl, wrap);
  },

  async fetchAll(onProgress) {
    return this.fetchAllParallel(onProgress);
  },

  async fetchImageBlob() {
    return this.fetchAllParallel();
  },

  abort() {
    this.abortController?.abort();
    this.pool?.stop();
    this.revokeBlobUrl();
    this.token = null;
    this.fileId = null;
    this.manifest = null;
    this.fileKey = null;
    this.chunks = null;
    this.completed = 0;
    this.pool = null;
    this.abortController = null;
    this.cachedEntry = null;
    this.cacheHit = false;
    this.offline = false;
    this.serverOffline = false;
  },
};
