const explorer = new Explorer();
let toastTimer = null;

const App = {
  backupPollTimer: null,
  rateLimitPollTimer: null,
  lastBackupSync: null,
  lastCapacity: null,
  lastCacheStats: null,
  storageReposExpanded: false,
  metadataReposExpanded: false,

  toast(message, type = '') {
    if (type === 'error') {
      console.error('[GitHub Vault]', message);
    }
    const el = document.getElementById('toast');
    el.textContent = message;
    el.className = 'toast' + (type ? ` ${type}` : '');
    el.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add('hidden'), 3000);
  },

  clearLegacyShareServiceWorker() {
    if (!('serviceWorker' in navigator)) return;
    navigator.serviceWorker.getRegistrations().then((regs) => {
      regs.forEach((reg) => {
        const url = reg.active?.scriptURL || reg.installing?.scriptURL || reg.waiting?.scriptURL || '';
        if (url.includes('/sw-share.js')) {
          reg.unregister().catch(() => {});
        }
      });
    }).catch(() => {});
  },

  setButtonLoading(btn, loading) {
    if (!btn) return;
    btn.classList.toggle('loading', loading);
    if (loading) {
      btn.dataset.prevDisabled = btn.disabled;
      btn.disabled = true;
    } else {
      btn.disabled = btn.dataset.prevDisabled === 'true';
      delete btn.dataset.prevDisabled;
    }
  },

  async withButton(btn, fn) {
    App.setButtonLoading(btn, true);
    try {
      await fn();
    } finally {
      App.setButtonLoading(btn, false);
    }
  },

  async refreshAll() {
    await explorer.refresh();
    await Promise.all([this.loadStats(), this.loadAccountViews()]);
  },

  async checkAuth(retries = 3) {
    for (let i = 0; i < retries; i++) {
      try {
        const auth = await API.auth.me();
        if (auth.authenticated) return auth;
      } catch { /* retry */ }
      if (i < retries - 1) await new Promise(r => setTimeout(r, 300));
    }
    return { authenticated: false };
  },

  async init() {
    this.clearLegacyShareServiceWorker();
    const params = new URLSearchParams(window.location.search);
    const auth = await this.checkAuth();

    if (auth.authenticated) {
      this.showApp(auth.user);
      if (params.get('linked') === '1') {
        this.toast('GitHub account linked successfully — backup sync started', 'success');
        window.history.replaceState({}, '', '/');
        setTimeout(() => this.loadAccountViews(), 1500);
      }
      if (params.get('error') === 'link_failed') {
        const reason = params.get('reason');
        this.toast(reason ? `Link failed: ${decodeURIComponent(reason)}` : 'Failed to link GitHub account', 'error');
        window.history.replaceState({}, '', '/');
      }
      if (params.has('error') && params.get('error') !== 'link_failed') {
        window.history.replaceState({}, '', '/');
      }
    } else {
      this.showLogin();
      if (params.get('error')) {
        const reason = params.get('reason');
        const msg = reason
          ? `Sign-in failed: ${decodeURIComponent(reason)}`
          : `GitHub authentication failed. Use ${window.location.origin} and try again.`;
        this.toast(msg, 'error');
        window.history.replaceState({}, '', '/');
      }
    }

    this.updateSetupUrls();
    this.bindEvents();
    Viewer.bindEvents();
    DownloadManager.bindEvents();
  },

  showLogin() {
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('app').classList.add('hidden');
  },

  showApp(user) {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    document.getElementById('user-name').textContent = user.username;
    document.getElementById('user-avatar').src = user.avatar || '';
    explorer.navigate('/');
    this.loadStats();
    explorer.buildFolderTree();
    TaskPanel.init();
    this.bindRepoSidebar();
    this.loadAccountViews();
    this.startBackupPoll();
    this.startRateLimitPoll();
    this.startViewersBadgePoll();
    const uploadMode = document.getElementById('upload-mode');
    if (uploadMode) uploadMode.value = UploadPrefs.get();
  },

  async loadAccountViews() {
    const select = document.getElementById('account-view');
    if (!select) return;

    try {
      const { views, backup_sync: backupSync } = await API.accounts.views();
      const current = explorer.accountView || 'primary';
      select.innerHTML = views.map((view) => (
        `<option value="${view.id}"${view.id === current ? ' selected' : ''}>${view.label}</option>`
      )).join('');

      this.lastBackupSync = backupSync;
      this.renderBackupWidget(backupSync);
      this.ensureBackupPoll();
    } catch {
      select.innerHTML = '<option value="primary">Primary</option>';
    }
  },

  renderBackupWidget(backupSync) {
    const widget = document.getElementById('backup-sync-widget');
    const label = document.getElementById('backup-sync-label');
    const pct = document.getElementById('backup-sync-pct');
    const fill = document.getElementById('backup-sync-fill');
    if (!widget || !label || !pct || !fill) return;

    if (!backupSync?.length) {
      widget.classList.add('hidden');
      return;
    }

    const syncing = backupSync.some((s) => s.syncing);
    const pending = backupSync.filter((s) => !s.up_to_date);
    const totalMissing = pending.reduce((sum, s) => sum + s.missing_chunks, 0);
    const totalChunks = backupSync.reduce((sum, s) => sum + s.total_chunks, 0) || 1;
    const synced = totalChunks - totalMissing;
    const percent = syncing
      ? Math.max(...backupSync.map((s) => s.percent || 0))
      : Math.round((synced / totalChunks) * 100);

    widget.classList.remove('hidden', 'syncing', 'done', 'rate-limited');
    fill.style.width = `${Math.min(100, Math.max(0, percent))}%`;

    const paused = backupSync.some((s) => s.paused);
    if (paused) {
      widget.classList.add('paused');
      const active = backupSync.find((s) => s.paused);
      label.textContent = active?.pause_reason || 'Paused';
      pct.textContent = `${percent}%`;
    } else if (syncing) {
      widget.classList.add('syncing');
      const active = backupSync.find((s) => s.syncing);
      const phase = active?.phase === 'rate-limit'
        ? (active.rate_limit_seconds
          ? `Rate limited (${active.rate_limit_seconds}s)`
          : 'Rate limited — waiting')
        : active?.phase === 'fork-sync' ? 'Syncing forks'
          : active?.phase === 'reconcile' ? 'Reconciling'
            : active?.phase === 'chunk-fallback' ? 'Uploading chunks'
              : 'Syncing backup';
      label.textContent = phase;
      if (active?.phase === 'rate-limit') widget.classList.add('rate-limited');
      pct.textContent = `${percent}%`;
    } else if (totalMissing > 0) {
      label.textContent = `${totalMissing} chunk${totalMissing === 1 ? '' : 's'} pending`;
      pct.textContent = `${percent}%`;
    } else {
      widget.classList.add('done');
      label.textContent = 'Backup up to date';
      pct.textContent = '100%';
    }
  },

  async forceBackupSync(accountId = null) {
    try {
      await API.accounts.startBackupSync(accountId, { force: true });
      App.toast('Backup sync force-started', 'success');
      await this.pollBackupStatus();
      TaskPanel.ensurePoll();
    } catch (err) {
      App.toast(err.message || 'Failed to start backup sync', 'error');
    }
  },

  ensureBackupPoll() {
    const needsPoll = this.lastBackupSync?.some(
      (s) => !s.up_to_date || s.syncing || s.paused || s.phase === 'rate-limit'
    );
    if (needsPoll) this.startBackupPoll();
    else this.stopBackupPoll();
  },

  startBackupPoll() {
    if (this.backupPollTimer) return;
    this.backupPollTimer = setInterval(() => this.pollBackupStatus(), 2500);
    this.pollBackupStatus();
  },

  stopBackupPoll() {
    if (!this.backupPollTimer) return;
    clearInterval(this.backupPollTimer);
    this.backupPollTimer = null;
  },

  startRateLimitPoll() {
    if (this.rateLimitPollTimer) return;
    this.loadRateLimits().catch(() => {});
    this.rateLimitPollTimer = setInterval(() => {
      this.loadRateLimits().catch(() => {});
    }, 60000);
  },

  stopRateLimitPoll() {
    if (!this.rateLimitPollTimer) return;
    clearInterval(this.rateLimitPollTimer);
    this.rateLimitPollTimer = null;
  },

  async pollBackupStatus() {
    try {
      const { backup_sync: backupSync } = await API.accounts.backupStatus();
      this.lastBackupSync = backupSync;
      this.renderBackupWidget(backupSync);
      if (!backupSync?.some((s) => !s.up_to_date || s.syncing || s.paused)) {
        this.stopBackupPoll();
        this.loadStats();
      }
    } catch {
      // keep polling through transient errors
    }
  },

  formatDuration(seconds) {
    if (!seconds || seconds <= 0) return 'now';
    if (seconds < 60) return `${seconds}s`;
    const mins = Math.ceil(seconds / 60);
    if (mins < 60) return `${mins} min`;
    const hrs = Math.floor(mins / 60);
    const rem = mins % 60;
    return rem ? `${hrs}h ${rem}m` : `${hrs}h`;
  },

  renderRateLimitAccount(account) {
    const usedPct = account.known ? (account.percent_used ?? 0) : 0;
    const cls = driveBarClass(usedPct);
    const remaining = account.known ? account.remaining : '?';
    const used = account.known ? account.used : '?';
    const limit = account.limit ?? 5000;
    const resetLabel = account.reset_in_seconds
      ? `resets in ${this.formatDuration(account.reset_in_seconds)}`
      : 'reset time unknown';
    const pauseBadge = account.paused
      ? `<span class="rate-limit-pause">${account.exhausted ? 'Exhausted' : 'Paused'} ${this.formatDuration(account.pause_seconds_left)}</span>`
      : '';
    const concurrency = account.thresholds?.current ?? account.recommended_concurrency ?? '—';

    return `
      <div class="rate-limit-item ${account.paused ? 'rate-limit-paused' : ''}" title="${account.label}">
        <div class="rate-limit-header">
          <span class="rate-limit-role">${account.role_label}</span>
          <span class="rate-limit-user">@${account.username}</span>
          ${pauseBadge}
        </div>
        <div class="drive-bar ${cls}">
          <div class="drive-bar-vault" style="width:${Math.min(100, usedPct)}%"></div>
        </div>
        <div class="rate-limit-detail">
          <span>${used} / ${limit} used</span>
          <span>${remaining} left</span>
        </div>
        <div class="rate-limit-meta">${resetLabel} · concurrency ${concurrency}</div>
      </div>
    `;
  },

  renderRateLimitPanel(accounts, targetId = 'rate-limit-panel') {
    const el = document.getElementById(targetId);
    if (!el) return;

    if (!accounts?.length) {
      el.innerHTML = '<div class="rate-limit-empty">No active accounts</div>';
      return;
    }

    const header = targetId === 'rate-limit-modal-panel'
      ? `<h4 class="rate-limit-modal-title">GitHub API quotas</h4>
         <p class="rate-limit-modal-hint">Each account has its own hourly request pool (typically 5,000/hr). Backup and primary are tracked separately.</p>`
      : '';
    el.innerHTML = header + accounts.map((a) => this.renderRateLimitAccount(a)).join('');
  },

  async loadRateLimits() {
    try {
      const { accounts } = await API.accounts.rateLimits();
      this.lastRateLimits = accounts;
      this.renderRateLimitPanel(accounts, 'rate-limit-panel');
      this.renderRateLimitPanel(accounts, 'rate-limit-modal-panel');
      return accounts;
    } catch {
      const el = document.getElementById('rate-limit-panel');
      if (el) el.innerHTML = '<div class="rate-limit-empty">Quota unavailable</div>';
      return [];
    }
  },

  async loadStats() {
    try {
      const [stats, capacity, cacheStats] = await Promise.all([
        API.files.stats(),
        API.repos.capacity().catch(() => null),
        API.cache.stats().catch(() => null),
      ]);

      const el = document.getElementById('storage-info');
      const activeRepos = stats.repos.filter(r => r.is_active && !r.is_metadata);
      el.innerHTML = `
        <div>${stats.fileCount} file${stats.fileCount !== 1 ? 's' : ''}</div>
        <div>${formatSize(stats.totalSize)} in vault</div>
        <div>${activeRepos.length} storage repo${activeRepos.length !== 1 ? 's' : ''}</div>
        <div>🔒 AES-256 encrypted</div>
        ${stats.metadata_repo ? `<div class="meta-repo-label" title="Metadata & thumbnails">📋 ${stats.metadata_repo}</div>` : ''}
      `;

      if (capacity) {
        this.renderDrives(capacity);
        document.getElementById('status-size').textContent =
          capacity.total.available > 0
            ? `${formatSize(capacity.total.available)} free across pool`
            : '';
      }

      if (cacheStats) {
        this.lastCacheStats = cacheStats;
        this.renderCacheDisk(cacheStats);
      }

      this.gitAvailable = !!stats.gitAvailable;
      const uploadMode = document.getElementById('upload-mode');
      const gitOption = uploadMode?.querySelector('option[value="git"]');
      if (gitOption) {
        gitOption.disabled = !this.gitAvailable;
        if (!this.gitAvailable && uploadMode.value === 'git') {
          uploadMode.value = 'api';
          UploadPrefs.set('api');
        }
      }
    } catch {
      // stats are optional
    }
  },

  hideCacheContextMenu() {
    document.getElementById('cache-context-menu')?.classList.add('hidden');
  },

  showCacheContextMenu(e) {
    e.preventDefault();
    e.stopPropagation();
    explorer.hideContextMenu();
    const menu = document.getElementById('cache-context-menu');
    menu.classList.remove('hidden');
    menu.style.left = `${e.clientX}px`;
    menu.style.top = `${e.clientY}px`;
  },

  async clearCacheDisk() {
    if (!confirm('Clear the cache disk? Cached downloads will need to be fetched again.')) return;
    try {
      const result = await API.cache.clear();
      this.toast(`Cache cleared — freed ${formatSize(result.freed)}`, 'success');
      this.loadStats();
    } catch (err) {
      this.toast(err.message, 'error');
    }
  },

  renderCacheDisk(cache) {
    const el = document.getElementById('cache-drive');
    if (!el) return;

    const free = Math.max(0, cache.max - cache.used);
    const maxGb = cache.maxGb || Math.round((cache.max / (1024 ** 3)) * 10) / 10;
    el.title = 'Right-click for cache options';
    el.innerHTML = `
      <div class="drive-header">
        <span class="drive-icon">💿</span>
        <span class="drive-label">Cache Disk</span>
        <button type="button" class="drive-cache-settings" title="Cache settings" aria-label="Cache settings">⚙</button>
      </div>
      ${renderDriveBar(cache.percent, cache.percent)}
      <div class="drive-detail">
        ${formatSize(cache.used)} used · ${formatSize(free)} free of ${formatSize(cache.max)} (${maxGb} GB max)
      </div>
      <div class="drive-breakdown">
        <span class="drive-legend cache">${cache.entries} cached file${cache.entries !== 1 ? 's' : ''}</span>
      </div>
    `;

    el.querySelector('.drive-cache-settings')?.addEventListener('click', (e) => {
      e.stopPropagation();
      this.openCacheSettings(cache);
    });
  },

  openCacheSettings(cache) {
    const modal = document.getElementById('cache-settings-modal');
    const input = document.getElementById('cache-max-gb');
    const usage = document.getElementById('cache-settings-usage');
    const maxGb = cache?.maxGb || Math.round(((cache?.max || 0) / (1024 ** 3)) * 10) / 10;
    if (input) input.value = maxGb || 10;
    if (usage && cache) {
      usage.textContent = `Currently using ${formatSize(cache.used)} of ${formatSize(cache.max)}. Lowering the limit may evict oldest entries.`;
    }
    modal?.classList.remove('hidden');
  },

  async saveCacheSettings() {
    const input = document.getElementById('cache-max-gb');
    const btn = document.getElementById('btn-save-cache-settings');
    const maxGb = parseFloat(input?.value);
    if (!Number.isFinite(maxGb)) {
      this.toast('Enter a valid cache size', 'error');
      return;
    }

    await App.withButton(btn, async () => {
      try {
        await API.cache.setMaxGb(maxGb);
        document.getElementById('cache-settings-modal')?.classList.add('hidden');
        this.toast(`Cache limit set to ${maxGb} GB`, 'success');
        await this.loadStats();
      } catch (err) {
        this.toast(err.message, 'error');
      }
    });
  },

  renderRepoDriveItem(repo) {
    return `
      <div class="drive-item ${repo.is_active ? '' : 'drive-inactive'} ${repo.is_metadata ? 'drive-metadata' : ''}">
        <div class="drive-header">
          <span class="drive-icon">${repo.is_metadata ? '📋' : '📀'}</span>
          <span class="drive-label" title="${repo.full_name}">${repo.is_metadata ? 'Metadata' : repo.name}</span>
        </div>
        ${repo.is_metadata
          ? '<div class="drive-detail">Manifests, keys & thumbnails</div>'
          : `${renderDriveBar(repo.vault_percent, repo.used_percent)}
             <div class="drive-detail">${formatSize(repo.vault_used || 0)} used · ${formatSize(repo.available)} free of ${formatSize(repo.capacity)}</div>`}
      </div>
    `;
  },

  renderStorageRepos() {
    const el = document.getElementById('repo-drives-storage');
    if (!el || !this.lastCapacity) return;
    const repos = this.lastCapacity.repos.filter((r) => !r.is_metadata);
    el.innerHTML = repos.length
      ? repos.map((repo) => this.renderRepoDriveItem(repo)).join('')
      : '<div class="drive-empty">No storage repos</div>';
    el.dataset.loaded = '1';
  },

  renderMetadataRepos() {
    const el = document.getElementById('repo-drives-metadata');
    if (!el || !this.lastCapacity) return;
    const repos = this.lastCapacity.repos.filter((r) => r.is_metadata);
    el.innerHTML = repos.length
      ? repos.map((repo) => this.renderRepoDriveItem(repo)).join('')
      : '<div class="drive-empty">No metadata repo</div>';
    el.dataset.loaded = '1';
  },

  updateRepoSidebarCounts() {
    const storageCount = document.getElementById('storage-repos-count');
    const metadataCount = document.getElementById('metadata-repos-count');
    if (!this.lastCapacity) return;
    const storage = this.lastCapacity.repos.filter((r) => !r.is_metadata);
    const metadata = this.lastCapacity.repos.filter((r) => r.is_metadata);
    if (storageCount) storageCount.textContent = storage.length ? `(${storage.length})` : '';
    if (metadataCount) metadataCount.textContent = metadata.length ? `(${metadata.length})` : '';
  },

  setRepoSectionExpanded(kind, expanded) {
    const isStorage = kind === 'storage';
    const toggle = document.getElementById(isStorage ? 'storage-repos-toggle' : 'metadata-repos-toggle');
    const body = document.getElementById(isStorage ? 'repo-drives-storage' : 'repo-drives-metadata');
    if (!toggle || !body) return;

    if (isStorage) this.storageReposExpanded = expanded;
    else this.metadataReposExpanded = expanded;

    toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    toggle.classList.toggle('expanded', expanded);
    body.classList.toggle('hidden', !expanded);
    body.hidden = !expanded;

    if (expanded) {
      if (isStorage) this.renderStorageRepos();
      else this.renderMetadataRepos();
    }
  },

  bindRepoSidebar() {
    const storageToggle = document.getElementById('storage-repos-toggle');
    const metadataToggle = document.getElementById('metadata-repos-toggle');
    if (!storageToggle || storageToggle.dataset.bound) return;
    storageToggle.dataset.bound = '1';

    storageToggle.addEventListener('click', () => {
      this.setRepoSectionExpanded('storage', !this.storageReposExpanded);
    });
    metadataToggle.addEventListener('click', () => {
      this.setRepoSectionExpanded('metadata', !this.metadataReposExpanded);
    });
  },

  renderDrives(capacity) {
    const totalEl = document.getElementById('total-drive');
    const t = capacity.total;
    this.lastCapacity = capacity;

    totalEl.innerHTML = `
      <div class="drive-header">
        <span class="drive-icon">💾</span>
        <span class="drive-label">GitHub Vault Pool</span>
      </div>
      ${renderDriveBar(t.vault_percent, t.used_percent)}
      <div class="drive-detail">
        ${formatSize(t.available)} free of ${formatSize(t.capacity)}
      </div>
      <div class="drive-breakdown">
        <span class="drive-legend vault">Vault ${formatSize(t.vault_used)}</span>
        <span class="drive-legend other">Other ${formatSize(t.other_used)}</span>
      </div>
    `;

    this.updateRepoSidebarCounts();

    const storageEl = document.getElementById('repo-drives-storage');
    const metadataEl = document.getElementById('repo-drives-metadata');
    if (storageEl?.dataset.loaded === '1' && this.storageReposExpanded) this.renderStorageRepos();
    if (metadataEl?.dataset.loaded === '1' && this.metadataReposExpanded) this.renderMetadataRepos();
  },

  bindEvents() {
    document.getElementById('btn-logout').addEventListener('click', async () => {
      await API.auth.logout();
      this.showLogin();
    });

    document.getElementById('btn-upload').addEventListener('click', () => {
      document.getElementById('file-input').click();
    });

    document.getElementById('file-input').addEventListener('change', (e) => {
      this.uploadFiles(e.target.files);
      e.target.value = '';
    });

    document.getElementById('btn-new-folder').addEventListener('click', () => this.openFolderModal());

    document.getElementById('upload-mode')?.addEventListener('change', (e) => {
      UploadPrefs.set(e.target.value);
    });

    document.getElementById('btn-create-folder').addEventListener('click', () => this.createFolder());
    document.getElementById('folder-name').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this.createFolder();
    });

    document.getElementById('btn-download').addEventListener('click', () => {
      App.withButton(document.getElementById('btn-download'), () => explorer.downloadSelected());
    });
    document.getElementById('btn-move').addEventListener('click', () => {
      explorer.showMoveDialog([...explorer.selected]);
    });
    document.getElementById('btn-confirm-move').addEventListener('click', () => explorer.confirmMove());
    document.getElementById('btn-delete').addEventListener('click', () => explorer.deleteSelected());
    document.getElementById('btn-refresh').addEventListener('click', () => {
      App.withButton(document.getElementById('btn-refresh'), () => App.refreshAll());
    });

    document.getElementById('btn-back').addEventListener('click', () => explorer.goBack());
    document.getElementById('btn-up').addEventListener('click', () => explorer.goUp());

    document.getElementById('btn-viewers')?.addEventListener('click', () => this.showViewersPanel());
    document.getElementById('btn-repos').addEventListener('click', () => this.showRepoModal());
    document.getElementById('backup-sync-force')?.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const accountId = this.lastBackupSync?.find((s) => !s.up_to_date || s.paused)?.account_id || null;
      await App.withButton(e.currentTarget, () => App.forceBackupSync(accountId));
    });

    document.getElementById('account-view')?.addEventListener('change', async (e) => {
      explorer.accountView = e.target.value || 'primary';
      const isPrimary = explorer.accountView === 'primary';
      document.getElementById('btn-upload')?.toggleAttribute('disabled', !isPrimary);
      document.getElementById('file-input')?.toggleAttribute('disabled', !isPrimary);
      await explorer.navigate(explorer.currentPath);
      this.loadAccountViews();
    });
    document.querySelectorAll('[data-copy-target]').forEach((btn) => {
      btn.addEventListener('click', () => this.copyTextFromElement(btn.dataset.copyTarget));
    });
    document.getElementById('btn-setup-vault-org')?.addEventListener('click', () => this.setupVaultOrg());
    document.getElementById('btn-clear-vault-org')?.addEventListener('click', () => this.clearVaultOrg());
    document.getElementById('vault-org-select')?.addEventListener('change', (e) => {
      const nameInput = document.getElementById('vault-org-name');
      if (nameInput && e.target.value) nameInput.value = e.target.value;
    });

    document.querySelectorAll('[data-close]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.getElementById(btn.dataset.close).classList.add('hidden');
      });
    });

    document.querySelectorAll('.modal').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.add('hidden');
      });
    });

    document.getElementById('cache-drive')?.addEventListener('contextmenu', (e) => {
      this.showCacheContextMenu(e);
    });

    document.getElementById('cache-context-menu')?.addEventListener('click', (e) => {
      const action = e.target.dataset.action;
      if (!action) return;
      this.hideCacheContextMenu();
      if (action === 'clear-cache') this.clearCacheDisk();
      if (action === 'cache-settings') this.openCacheSettings(this.lastCacheStats);
    });

    document.getElementById('btn-save-cache-settings')?.addEventListener('click', () => {
      this.saveCacheSettings();
    });

    document.getElementById('context-menu').addEventListener('click', (e) => {
      e.stopPropagation();
      const action = e.target.dataset.action;
      if (!action) return;
      const mode = explorer.contextMode;
      explorer.hideContextMenu();

      if (mode === 'blank') {
        if (action === 'new-folder') this.openFolderModal();
        if (action === 'upload') document.getElementById('file-input').click();
        if (action === 'refresh-view') App.refreshAll();
        return;
      }

      const file = explorer.contextTarget;
      if (!file) return;

      if (action === 'open' && file.is_folder) explorer.openItem(file);
      if (action === 'preview' && !file.is_folder) Viewer.open(file);
      if (action === 'rename') explorer.startRename(file);
      if (action === 'details') App.showDetails(file);
      if (action === 'share') App.shareFile(file);
      if (action === 'download' && !file.is_folder) explorer.downloadFile(file);
      if (action === 'move') explorer.showMoveDialog([...explorer.selected]);
      if (action === 'refresh-thumb' && !file.is_folder) explorer.refreshThumbnail(file);
      if (action === 'delete') {
        explorer.selected.clear();
        explorer.selected.add(file.id);
        explorer.deleteSelected();
      }
    });

    document.addEventListener('click', () => {
      explorer.hideContextMenu();
      this.hideCacheContextMenu();
    });

    const fileView = document.getElementById('file-view');
    const dropOverlay = document.getElementById('drop-overlay');

    fileView.addEventListener('contextmenu', (e) => {
      if (e.target.closest('.file-item')) return;
      explorer.showBlankContextMenu(e);
    });

    document.addEventListener('keydown', (e) => {
      if (e.key !== 'F2' || explorer.selected.size !== 1) return;
      const id = [...explorer.selected][0];
      const file = explorer.files.find((entry) => entry.id === id);
      if (file && !file.pending) {
        e.preventDefault();
        explorer.startRename(file);
      }
    });

    fileView.addEventListener('dragover', (e) => {
      if (e.dataTransfer.types.includes('application/x-vault-move')) return;
      e.preventDefault();
      dropOverlay.classList.remove('hidden');
    });

    fileView.addEventListener('dragleave', (e) => {
      if (!fileView.contains(e.relatedTarget)) dropOverlay.classList.add('hidden');
    });

    fileView.addEventListener('drop', (e) => {
      if (e.dataTransfer.types.includes('application/x-vault-move')) return;
      e.preventDefault();
      dropOverlay.classList.add('hidden');
      if (e.dataTransfer.files.length) this.uploadFiles(e.dataTransfer.files);
    });

    document.querySelectorAll('.sidebar-item[data-view]').forEach((item) => {
      item.addEventListener('click', () => {
        if (item.dataset.view === 'viewers') {
          this.showViewersPanel();
          return;
        }
        this.showFilesPanel();
        if (item.dataset.path) {
          explorer.pushHistory(item.dataset.path);
          explorer.navigate(item.dataset.path);
        }
      });
    });

    document.getElementById('share-copy').addEventListener('click', () => {
      const input = document.getElementById('share-url');
      input.select();
      navigator.clipboard.writeText(input.value).then(() => App.toast('Link copied', 'success'));
    });

    const shareClientToggle = document.getElementById('share-client-stream');
    if (shareClientToggle) {
      shareClientToggle.addEventListener('change', async (e) => {
        try {
          await API.files.setShareSettings(e.target.checked);
          this.toast(
            e.target.checked ? 'Share links will decrypt in the browser' : 'Share links will stream via server',
            'success'
          );
        } catch (err) {
          e.target.checked = !e.target.checked;
          this.toast(err.message, 'error');
        }
      });
    }
  },

  startViewersBadgePoll() {
    const update = async () => {
      if (LiveViewers.active) return;
      try {
        const data = await API.viewers.live();
        const badge = document.getElementById('viewers-badge');
        const total = data?.totalViewers || 0;
        if (badge) {
          badge.textContent = String(total);
          badge.classList.toggle('hidden', total === 0);
        }
      } catch { /* ignore */ }
    };
    update();
    if (this.viewersBadgeTimer) clearInterval(this.viewersBadgeTimer);
    this.viewersBadgeTimer = setInterval(update, 30000);
  },

  showViewersPanel() {
    LiveViewers.show();
  },

  showFilesPanel() {
    LiveViewers.hide();
    document.querySelectorAll('.sidebar-item[data-view]').forEach((el) => {
      el.classList.toggle('active', el.dataset.view === 'files');
    });
  },

  openFolderModal() {
    document.getElementById('folder-modal').classList.remove('hidden');
    document.getElementById('folder-name').value = '';
    document.getElementById('folder-name').focus();
  },

  async uploadFiles(fileList) {
    const files = [...fileList];
    if (!files.length) return;

    const uploadMode = UploadPrefs.get();

    for (const file of files) {
      let chunkSize = 921600;
      let mode = uploadMode;
      if (file.size > 100 * 1024 * 1024) {
        const confirmed = await this.showUploadPlan(file);
        if (!confirmed) continue;
        chunkSize = confirmed.chunkSize;
        mode = confirmed.uploadMode || uploadMode;
      }
      await this.uploadSingleFile(file, chunkSize, mode);
    }
    await this.loadStats();
  },

  chunkSizeFromMbInput(input) {
    const MB = 1024 * 1024;
    const maxMb = parseFloat(input.max) || 95;
    const minMb = parseFloat(input.min) || 0.064;
    const mb = parseFloat(input.value);
    const clamped = Math.min(maxMb, Math.max(minMb, Number.isFinite(mb) ? mb : 0.9));
    return Math.round(clamped * MB);
  },

  async showUploadPlan(file) {
    return new Promise((resolve) => {
      const modal = document.getElementById('upload-plan-modal');
      const chunkInput = document.getElementById('plan-chunk-size');
      const body = document.getElementById('plan-body');
      const GB = 1024 * 1024 * 1024;

      const modeSelect = document.getElementById('plan-upload-mode');
      const gitAvailable = App.gitAvailable !== false;

      const render = async () => {
        const cs = this.chunkSizeFromMbInput(chunkInput);
        const selectedMode = modeSelect?.value || UploadPrefs.get();
        try {
          const plan = await API.files.plan(file.size, cs);
          if (plan.maxChunkMb) {
            chunkInput.max = String(plan.maxChunkMb);
          }
          body.innerHTML = `
            <p><strong>${file.name}</strong> — ${formatSize(file.size)}</p>
            <div class="plan-grid">
              <div><span class="plan-label">Chunks</span><span>${plan.totalChunks}</span></div>
              <div><span class="plan-label">Chunk size</span><span>${plan.chunkSizeMb} MB</span></div>
              <div><span class="plan-label">Repos</span><span>${plan.repoCount}</span></div>
              <div><span class="plan-label">Est. time</span><span>${plan.estimatedTime}</span></div>
            </div>
            <p class="plan-note">GitHub Contents API limit: ${plan.githubMaxMb} MB per stored file.</p>
            <p class="plan-note">Upload method: <strong>${selectedMode === 'git' ? 'Git clone & push' : 'API chunks (resumable)'}</strong></p>
            <h4>Distribution</h4>
            <div class="plan-repos">${Object.entries(plan.perRepo).map(([r, n]) =>
              `<div class="plan-repo-row"><span>${r}</span><span>${n} chunks</span></div>`
            ).join('')}</div>
            ${plan.distributionTruncated ? '<p class="plan-note">Showing summary — chunks round-robin across repos.</p>' : ''}
          `;
        } catch (e) {
          body.innerHTML = `<p class="plan-error">${e.message}</p>`;
        }
      };

      if (modeSelect) {
        modeSelect.value = UploadPrefs.get();
        modeSelect.disabled = !gitAvailable;
        modeSelect.onchange = render;
      }

      chunkInput.value = file.size > 2 * GB ? '4' : '0.9';
      modal.classList.remove('hidden');
      render();
      chunkInput.oninput = render;

      const cleanup = () => {
        modal.classList.add('hidden');
        document.getElementById('plan-cancel').onclick = null;
        document.getElementById('plan-confirm').onclick = null;
      };

      document.getElementById('plan-cancel').onclick = () => { cleanup(); resolve(null); };
      document.getElementById('plan-confirm').onclick = () => {
        const cs = this.chunkSizeFromMbInput(chunkInput);
        const uploadMode = modeSelect?.value || UploadPrefs.get();
        UploadPrefs.set(uploadMode);
        cleanup();
        resolve({ chunkSize: cs, uploadMode });
      };
    });
  },

  async uploadSingleFile(file, chunkSize, uploadMode = 'api') {
    const uploadBtn = document.getElementById('btn-upload');
    const pendingId = `pending-${Date.now()}`;

    App.setButtonLoading(uploadBtn, true);

    const placeholder = {
      id: pendingId, name: file.name, is_folder: 0, size: file.size,
      pending: true, uploadPercent: 0, uploadStatus: 'Starting...',
    };
    explorer.files.push(placeholder);
    explorer.render();

    try {
      await API.files.upload(file, explorer.currentPath, chunkSize, (job) => {
        const pct = job.percent || 0;
        let status = 'Processing...';
        if (job.phase === 'encrypt') status = 'Encrypting...';
        else if (job.phase === 'git-push') status = 'Pushing via git...';
        else if (job.phase === 'upload' && job.chunksTotal) {
          status = `Chunk ${job.chunksDone}/${job.chunksTotal}`;
          if (job.currentRepo) status += ` → ${job.currentRepo.split('/').pop()}`;
        } else if (job.phase === 'metadata') status = 'Saving metadata...';

        explorer.updatePendingProgress(pendingId, pct, status);
        if (job.id) TaskPanel.tasks.set(job.id, job);
        TaskPanel.render();
      }, uploadMode);

      explorer.files = explorer.files.filter((f) => f.id !== pendingId);
      await explorer.refresh({ filesOnly: true });
    } catch (err) {
      explorer.files = explorer.files.filter((f) => f.id !== pendingId);
      explorer.render();
      this.toast(`Upload interrupted: ${err?.message || String(err) || 'unknown error'}. Resume from Background tasks.`, 'error');
    }

    App.setButtonLoading(uploadBtn, false);
  },

  async showDetails(file) {
    const modal = document.getElementById('details-modal');
    const body = document.getElementById('details-body');
    modal.classList.remove('hidden');
    body.innerHTML = '<div class="details-loading">Loading...</div>';

    try {
      const d = await API.files.details(file.id);
      body.innerHTML = `
        <div class="details-section">
          <h3>${d.file.name}</h3>
          <div class="details-grid">
            <span>Path</span><span>${d.file.path}</span>
            <span>Size</span><span>${formatSize(d.file.size)}</span>
            <span>Type</span><span>${d.file.mime_type || 'unknown'}</span>
            <span>Chunks</span><span>${d.file.chunk_count}</span>
            <span>Encryption</span><span>${d.file.encryption_mode || 'chunk'}</span>
            <span>Created</span><span>${new Date(d.file.created_at).toLocaleString()}</span>
          </div>
        </div>
        <div class="details-section">
          <h4>Repos used</h4>
          ${Object.entries(d.repos_used).map(([r, n]) => `<div class="plan-repo-row"><span>${r}</span><span>${n} chunks</span></div>`).join('')}
        </div>
        <div class="details-section details-chunks">
          <h4>Chunk map</h4>
          <table class="chunk-table">
            <thead><tr><th>#</th><th>Repo</th><th>Path</th><th>Size</th><th>SHA</th></tr></thead>
            <tbody>${d.chunks.map(c => `
              <tr>
                <td>${c.index}</td>
                <td>${c.repo}</td>
                <td class="mono">${c.path}</td>
                <td>${formatSize(c.plain_size)}</td>
                <td class="mono sha-cell">${(c.sha || '').slice(0, 8)}…</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      `;
    } catch (err) {
      body.innerHTML = `<p class="plan-error">${err.message}</p>`;
    }
  },

  async shareFile(file) {
    try {
      const [result, settings] = await Promise.all([
        API.files.share(file.id),
        API.files.shareSettings().catch(() => ({ client_stream: true })),
      ]);
      document.getElementById('share-url').value = result.url;
      const toggle = document.getElementById('share-client-stream');
      if (toggle) toggle.checked = !!settings.client_stream;
      document.getElementById('share-modal').classList.remove('hidden');
    } catch (err) {
      this.toast(err.message, 'error');
    }
  },

  async createFolder() {
    const name = document.getElementById('folder-name').value.trim();
    if (!name) return;

    const btn = document.getElementById('btn-create-folder');
    App.setButtonLoading(btn, true);

    try {
      await API.files.createFolder(name, explorer.currentPath);
      document.getElementById('folder-modal').classList.add('hidden');
      this.toast(`Created folder "${name}"`, 'success');
      await this.refreshAll();
    } catch (err) {
      this.toast(err.message, 'error');
    } finally {
      App.setButtonLoading(btn, false);
    }
  },

  updateSetupUrls() {
    const origin = window.location.origin;
    const callback = `${origin}/auth/github/callback`;
    const setText = (id, value) => {
      const el = document.getElementById(id);
      if (el) el.textContent = value;
    };
    setText('setup-homepage-url', origin);
    setText('setup-callback-url', callback);
    setText('repo-setup-callback-url', callback);
  },

  async updateLinkUrls() {
    const storageInput = document.getElementById('link-url-storage');
    const backupInput = document.getElementById('link-url-backup');
    const expiryEl = document.getElementById('link-url-expiry');
    if (!storageInput || !backupInput) return;

    storageInput.value = 'Generating one-time link…';
    backupInput.value = 'Generating one-time link…';

    try {
      const [storage, backup] = await Promise.all([
        API.accounts.createLinkToken('storage'),
        API.accounts.createLinkToken('backup'),
      ]);
      storageInput.value = storage.url;
      backupInput.value = backup.url;
      if (expiryEl) {
        expiryEl.textContent = `Each link works once and expires in ${storage.expires_in_minutes} minutes.`;
      }
    } catch (err) {
      storageInput.value = '';
      backupInput.value = '';
      this.toast(err.message, 'error');
    }
  },

  async copyTextFromElement(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const text = el.value ?? el.textContent ?? '';
    if (!text) return;
    const isLinkInput = el.tagName === 'INPUT';
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      if (isLinkInput) {
        el.select();
        document.execCommand('copy');
      }
    }
    this.toast(
      isLinkInput ? 'Link copied — open it in a private window' : 'Callback URL copied',
      'success'
    );
  },

  async showRepoModal() {
    document.getElementById('repo-modal').classList.remove('hidden');
    this.updateSetupUrls();
    await Promise.all([
      this.updateLinkUrls(),
      this.loadRateLimits(),
      this.loadLinkedAccounts(),
      this.loadOrgPanel(),
      this.loadRepos(),
    ]);
  },

  async loadLinkedAccounts() {
    const listEl = document.getElementById('linked-accounts-list');
    if (!listEl) return;

    try {
      const { accounts } = await API.accounts.list();
      if (!accounts.length) {
        listEl.innerHTML = '<p class="linked-accounts-empty">No linked accounts yet.</p>';
        return;
      }

      listEl.innerHTML = '';
      for (const account of accounts) {
        const card = document.createElement('div');
        card.className = 'linked-account-card';

        const roleLabel = account.role === 'backup' ? 'Backup / redundancy' : 'Additional storage';
        const statusLabel = account.is_active ? 'Active' : 'Inactive';

        const quota = this.lastRateLimits?.find(
          (q) => (account.id == null && q.is_primary) || q.id === account.id
            || (q.username === account.username && q.role === account.role)
        );
        const quotaHtml = quota?.known ? `
          <div class="linked-account-quota">
            <span>${quota.used}/${quota.limit} API calls</span>
            <span>${quota.remaining} left${quota.paused ? ` · paused ${this.formatDuration(quota.pause_seconds_left)}` : ''}</span>
          </div>
        ` : '';

        card.innerHTML = `
          <div class="linked-account-info">
            <img class="linked-account-avatar" src="${account.avatar_url || ''}" alt="">
            <div>
              <span class="linked-account-name">@${account.username}</span>
              <span class="linked-account-meta">${roleLabel} · ${statusLabel}</span>
              ${quotaHtml}
            </div>
          </div>
        `;

        const actions = document.createElement('div');
        actions.className = 'linked-account-actions';

        const roleSelect = document.createElement('select');
        roleSelect.className = 'linked-account-role';
        roleSelect.innerHTML = `
          <option value="storage"${account.role === 'storage' ? ' selected' : ''}>Storage</option>
          <option value="backup"${account.role === 'backup' ? ' selected' : ''}>Backup</option>
        `;
        roleSelect.addEventListener('change', async () => {
          try {
            await API.accounts.update(account.id, { role: roleSelect.value });
            this.toast(`@${account.username} set to ${roleSelect.value}`, 'success');
            await this.loadLinkedAccounts();
            await this.loadRepos();
          } catch (err) {
            this.toast(err.message, 'error');
            roleSelect.value = account.role;
          }
        });
        actions.appendChild(roleSelect);

        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'btn-secondary';
        toggleBtn.textContent = account.is_active ? 'Disable' : 'Enable';
        toggleBtn.addEventListener('click', async () => {
          try {
            await API.accounts.update(account.id, { is_active: !account.is_active });
            await this.loadLinkedAccounts();
            await this.loadRepos();
          } catch (err) {
            this.toast(err.message, 'error');
          }
        });
        actions.appendChild(toggleBtn);

        if (account.role === 'backup') {
          const redoBtn = document.createElement('button');
          redoBtn.className = 'btn-primary';
          redoBtn.textContent = 'Re-fork repos';
          redoBtn.title = 'Reset backup repo mapping and fork primary repos again';
          redoBtn.addEventListener('click', async () => {
            if (!confirm(`Re-fork all storage repos to @${account.username}? This re-discovers forks and restarts backup sync.`)) return;
            App.setButtonLoading(redoBtn, true);
            try {
              const result = await API.accounts.redoBackup(account.id);
              this.toast(`Re-forked ${result.count} repo(s) for @${account.username}`, 'success');
              await Promise.all([this.loadLinkedAccounts(), this.loadRepos(), this.loadAccountViews(), this.loadStats()]);
            } catch (err) {
              this.toast(err.message, 'error');
            } finally {
              App.setButtonLoading(redoBtn, false);
            }
          });
          actions.appendChild(redoBtn);
        }

        const unlinkBtn = document.createElement('button');
        unlinkBtn.className = 'btn-danger';
        unlinkBtn.textContent = 'Unlink';
        unlinkBtn.addEventListener('click', async () => {
          if (!confirm(`Unlink @${account.username}?`)) return;
          try {
            await API.accounts.unlink(account.id);
            this.toast(`Unlinked @${account.username}`, 'success');
            await this.loadLinkedAccounts();
            await this.loadRepos();
            await this.loadStats();
          } catch (err) {
            this.toast(err.message, 'error');
          }
        });
        actions.appendChild(unlinkBtn);

        card.appendChild(actions);
        listEl.appendChild(card);
      }
    } catch (err) {
      listEl.innerHTML = `<p class="linked-accounts-empty">${err.message}</p>`;
    }
  },

  async loadOrgPanel() {
    const select = document.getElementById('vault-org-select');
    const statusEl = document.getElementById('vault-org-status');
    const nameInput = document.getElementById('vault-org-name');
    if (!select || !statusEl) return;

    try {
      const [{ org: vaultOrg, configured }, { orgs, needs_reauth: needsReauth }] = await Promise.all([
        API.repos.org(),
        API.repos.orgs(),
      ]);

      const selectable = orgs.filter((o) => o.role === 'admin' || o.role === 'unknown');
      select.innerHTML = '<option value="">Select an organization…</option>'
        + selectable.map((o) => {
          const suffix = o.role === 'unknown' ? ' (from repos)' : '';
          return `<option value="${o.login}"${vaultOrg === o.login ? ' selected' : ''}>${o.login}${suffix}</option>`;
        }).join('');

      if (needsReauth) {
        statusEl.innerHTML = `
          <span class="org-status-warn">GitHub needs organization permission to list your orgs.</span>
          <a class="org-reconnect-link" href="/auth/github/reconnect">Reconnect GitHub</a>
          <span class="org-status-hint"> — or type your org name below and click Set up org storage.</span>
        `;
      } else if (!selectable.length) {
        statusEl.innerHTML = `
          <span class="org-status-hint">No organizations found where you are an owner/admin.</span>
          <a class="org-create-link" href="https://github.com/account/organizations/new" target="_blank" rel="noopener">Create one on GitHub</a>
          <span class="org-status-hint">, then type its name below.</span>
        `;
      } else if (vaultOrg) {
        nameInput.value = vaultOrg;
        statusEl.innerHTML = `<span class="org-status-active">Active vault org: <strong>${vaultOrg}</strong> · ${configured.length} storage repo${configured.length !== 1 ? 's' : ''}</span>`;
      } else {
        statusEl.textContent = 'No vault organization configured — storage repos are created on your personal account.';
      }
    } catch (err) {
      statusEl.textContent = err.message;
      if (/403|scope/i.test(err.message)) {
        statusEl.innerHTML = `${err.message} <a class="org-reconnect-link" href="/auth/github/reconnect">Reconnect GitHub</a>`;
      }
    }
  },

  async setupVaultOrg() {
    const select = document.getElementById('vault-org-select');
    const nameInput = document.getElementById('vault-org-name');
    const countInput = document.getElementById('vault-org-repo-count');
    const btn = document.getElementById('btn-setup-vault-org');
    const org = (nameInput?.value || select?.value || '').trim().toLowerCase();
    const repoCount = parseInt(countInput?.value, 10) || 3;

    if (!org) {
      this.toast('Select or enter an organization name', 'error');
      return;
    }

    App.setButtonLoading(btn, true);
    try {
      const result = await API.repos.setupOrg(org, repoCount);
      this.toast(`Vault org ${result.org} ready with ${result.repos.length} repo(s)`, 'success');
      await Promise.all([this.loadOrgPanel(), this.loadRepos(), this.loadStats()]);
    } catch (err) {
      this.toast(err.message, 'error');
    } finally {
      App.setButtonLoading(btn, false);
    }
  },

  async clearVaultOrg() {
    try {
      await API.repos.clearOrg();
      this.toast('Vault org preference cleared', 'success');
      await this.loadOrgPanel();
    } catch (err) {
      this.toast(err.message, 'error');
    }
  },

  async loadRepos() {
    const configuredEl = document.getElementById('configured-repos');
    const availableEl = document.getElementById('available-repos');
    configuredEl.innerHTML = '<div style="padding:8px;color:#8a8a8a">Loading...</div>';
    availableEl.innerHTML = '';

    try {
      const [configured, available] = await Promise.all([
        API.repos.configured(),
        API.repos.available(),
      ]);

      configuredEl.innerHTML = configured.repos.length ? '' : '<div style="padding:8px;color:#8a8a8a">No repos configured. Add one below.</div>';
      for (const repo of configured.repos) {
        configuredEl.appendChild(this.createRepoCard(repo, true));
      }

      const unconfigured = available.repos.filter(r => !r.configured);
      availableEl.innerHTML = unconfigured.length ? '' : '<div style="padding:8px;color:#8a8a8a">All repos are already configured.</div>';
      for (const repo of unconfigured) {
        availableEl.appendChild(this.createRepoCard(repo, false));
      }
    } catch (err) {
      configuredEl.innerHTML = `<div style="padding:8px;color:#c42b1c">${err.message}</div>`;
    }
  },

  createRepoCard(repo, isConfigured) {
    const card = document.createElement('div');
    card.className = 'repo-card';

    const info = document.createElement('div');
    info.className = 'repo-info';

    let driveHtml = '';
    if (isConfigured && repo.capacity != null) {
      driveHtml = `
        <div class="repo-drive">
          ${renderDriveBar(repo.vault_percent || 0, repo.used_percent || 0)}
          <span class="repo-drive-text">
            ${formatSize(repo.available || 0)} free of ${formatSize(repo.capacity || 0)}
            · Vault ${formatSize(repo.vault_used || repo.total_bytes || 0)}
          </span>
        </div>
      `;
    }

    const accountBadge = repo.account_username
      ? `<span class="repo-account-badge">@${repo.account_username}</span>`
      : '';

    info.innerHTML = `
      <span class="repo-name">${repo.full_name || repo.name} ${accountBadge}</span>
      <span class="repo-meta">
        ${isConfigured
          ? `${repo.private === false || repo.is_public ? 'Public' : 'Private'} · ${repo.chunk_count || 0} chunks · ${formatSize(repo.vault_used || repo.total_bytes || 0)} vault data`
          : `${repo.private ? 'Private' : 'Public'}${repo.account_username ? ` · @${repo.account_username}` : ''}`}
      </span>
      ${driveHtml}
    `;

    const actions = document.createElement('div');
    actions.style.display = 'flex';
    actions.style.gap = '6px';
    actions.style.alignItems = 'center';

    if (isConfigured) {
      if (repo.is_metadata) {
        const badge = document.createElement('span');
        badge.className = 'repo-badge metadata';
        badge.textContent = 'Metadata';
        actions.appendChild(badge);
      } else if (repo.is_backup) {
        const badge = document.createElement('span');
        badge.className = 'repo-badge backup';
        badge.textContent = 'Backup mirror';
        actions.appendChild(badge);
      } else {
        const badge = document.createElement('span');
        badge.className = 'repo-badge' + (repo.is_active ? '' : ' inactive');
        badge.textContent = repo.is_active ? 'Active' : 'Inactive';
        actions.appendChild(badge);

        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'btn-secondary';
        toggleBtn.textContent = repo.is_active ? 'Disable' : 'Enable';
        toggleBtn.addEventListener('click', async () => {
          await API.repos.toggle(repo.id, !repo.is_active);
          this.loadRepos();
          this.loadStats();
        });
        actions.appendChild(toggleBtn);

        const removeBtn = document.createElement('button');
        removeBtn.className = 'btn-danger';
        removeBtn.textContent = 'Remove';
        removeBtn.addEventListener('click', async () => {
          if (!confirm(`Remove ${repo.full_name} from storage pool?`)) return;
          try {
            await API.repos.remove(repo.id);
            this.toast('Repo removed', 'success');
            this.loadRepos();
            this.loadStats();
          } catch (err) {
            this.toast(err.message, 'error');
          }
        });
        actions.appendChild(removeBtn);
      }
    } else {
      const addBtn = document.createElement('button');
      addBtn.className = 'btn-primary';
      addBtn.textContent = 'Add';
      addBtn.addEventListener('click', async () => {
        try {
          await API.repos.add(repo.full_name, repo.linked_account_id || undefined);
          this.toast(`Added ${repo.full_name}`, 'success');
          this.loadRepos();
          this.loadStats();
        } catch (err) {
          this.toast(err.message, 'error');
        }
      });
      actions.appendChild(addBtn);
    }

    card.appendChild(info);
    card.appendChild(actions);
    return card;
  },
};

document.getElementById('btn-create-repo').addEventListener('click', async () => {
  try {
    const result = await API.repos.create();
    App.toast(`Created ${result.repo.full_name}`, 'success');
    App.loadRepos();
    App.loadStats();
  } catch (err) {
    App.toast(err.message, 'error');
  }
});

document.getElementById('btn-make-repos-public')?.addEventListener('click', async () => {
  const msg = 'Make all primary storage repos public on GitHub?\n\n'
    + 'This enables offline share playback via raw.githubusercontent.com. '
    + 'Chunks remain encrypted — only ciphertext is exposed.';
  if (!confirm(msg)) return;
  const btn = document.getElementById('btn-make-repos-public');
  btn.disabled = true;
  try {
    const result = await API.post('/api/repos/make-public');
    const failed = (result.results || []).filter((r) => !r.ok);
    if (failed.length) {
      App.toast(`${result.made_public}/${result.total} repos public — ${failed[0].error}`, 'error');
    } else {
      App.toast(`${result.made_public} storage repo(s) are now public`, 'success');
    }
    await App.loadRepos();
  } catch (err) {
    App.toast(err.message, 'error');
  } finally {
    btn.disabled = false;
  }
});

document.addEventListener('DOMContentLoaded', () => App.init());
