# GitHub Vault

Distributed file storage across multiple GitHub repositories. Upload files, split them into chunks distributed across your repos, and download them reassembled — like a personal unlimited storage vault powered by GitHub.

## Features

- **GitHub OAuth** — Sign in with your GitHub account
- **Multi-repo storage** — Split files across multiple repositories for distributed storage
- **Chunk-based splitting** — Files are split into ~900KB chunks and round-robin distributed
- **Metadata tracking** — SQLite database tracks where every chunk lives
- **Torrent-like downloads** — Chunks are fetched from multiple repos and reassembled on download
- **Windows Explorer UI** — Familiar file manager interface with drag-and-drop upload

## Setup

### 1. Create a GitHub OAuth App

1. Go to [GitHub Developer Settings](https://github.com/settings/developers)
2. Click **New OAuth App**
3. Fill in:
   - **Application name**: GitHub Vault
   - **Homepage URL**: `http://localhost:3000`
   - **Authorization callback URL**: `http://localhost:3000/auth/github/callback`
4. Copy the **Client ID** and generate a **Client Secret**

### 2. Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your GitHub OAuth credentials:

```
GITHUB_CLIENT_ID=your_client_id
GITHUB_CLIENT_SECRET=your_client_secret
SESSION_SECRET=some_random_secret_string
APP_URL=http://localhost:3000
```

### 3. Install & Run

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Usage

1. **Sign in** with your GitHub account
2. **Add storage repos** — Click "Repos" in the toolbar to add existing repos or create new private ones
3. **Upload files** — Drag and drop or click Upload; files are automatically split and distributed
4. **Browse** — Navigate folders like Windows Explorer
5. **Download** — Select files and click Download; chunks are fetched and reassembled

## How It Works

```
Upload:  file.bin → [chunk0, chunk1, chunk2, ...] → distributed across repos
         repo-A/.vault/chunks/{id}/00000.bin
         repo-B/.vault/chunks/{id}/00001.bin
         repo-C/.vault/chunks/{id}/00002.bin

Download: fetch all chunks by metadata → concatenate → original file
```

Metadata (file names, paths, chunk locations, SHAs) is stored locally in SQLite. Chunk data lives in your GitHub repos under `.vault/chunks/`.

## Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `CHUNK_SIZE` | 921600 (900KB) | Size of each chunk in bytes |
| `PORT` | 3000 | Server port |
| `APP_URL` | http://localhost:3000 | Must match OAuth callback base URL |
